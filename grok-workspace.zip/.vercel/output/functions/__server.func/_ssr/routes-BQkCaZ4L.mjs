import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronDown, a as Store, c as Send, d as Mail, f as Landmark, g as CircleHelp, h as Copy, l as Phone, m as CreditCard, n as Wifi, o as Signal, p as FileCheck, r as User, s as Shield, t as X, u as MessageCircle, v as Briefcase, y as Battery } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BQkCaZ4L.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var OFFICER = {
	name: "Md. Mizanor Rahman Hridoy",
	title: "Assistant Officer & Bangla QR Branding Officer, Uttara Corporate Branch, Trust Bank PLC",
	email: "mizanor.rahman@tblbd.com",
	whatsapp: "8801538043323"
};
var INCOME_CHIPS = [
	18e3,
	3e4,
	5e4,
	1e5,
	2e5,
	4e5
];
var RULES = {
	classic: {
		inc: {
			govt: 15e3,
			private: 3e4,
			self: 4e4
		},
		ten: "About 1 year of experience (6 months with your current employer), or 2 years in business."
	},
	gold: {
		inc: {
			govt: 15e3,
			private: 3e4,
			self: 4e4
		},
		ten: "About 1 year of experience (6 months with your current employer), or 2 years in business."
	},
	platinum: {
		inc: {
			govt: 5e4,
			private: 1e5,
			self: 15e4
		},
		ten: "About 5 years of experience, or 3 years in business."
	},
	signature: {
		inc: {
			govt: 1e5,
			private: 15e4,
			self: 2e5
		},
		ten: "About 5 years of experience, or 5 years in business."
	}
};
var CARDS = {
	classic: {
		name: "Visa Classic",
		short: "Classic",
		limit: "Up to BDT 1.2 lac",
		fee: "BDT 1,000 a year",
		tone: "classic",
		feats: [
			"Up to 45 days interest-free on purchases when you pay the full statement amount",
			"Annual fee waived from year 2 after 18 POS or e-commerce transactions (BDT 500 or more each)",
			"Up to 4 supplementary cards, the first one free",
			"EMV chip-secured card, with 0% EMI and discounts at listed merchants",
			"Transaction alerts by email and SMS",
			"50% off the card fee for serving defence personnel"
		]
	},
	gold: {
		name: "Visa Gold",
		short: "Gold",
		limit: "BDT 1.2 lac to 5 lac",
		fee: "BDT 2,000 a year",
		tone: "gold",
		feats: [
			"Everything in Classic",
			"Airport Meet and Greet for the cardholder",
			"No cash withdrawal fee at Trust Bank ATMs (interest still applies on cash withdrawals)",
			"Pay bills through internet banking and mobile apps"
		]
	},
	platinum: {
		name: "Visa Platinum",
		short: "Platinum",
		limit: "BDT 2 lac to 5 lac",
		fee: "BDT 3,000 a year",
		tone: "platinum",
		feats: [
			"2 free international airport lounge visits a year, plus 1 Balaka Lounge visit",
			"Airport Meet and Greet with 2 companions",
			"Offers at partner merchants such as Aarong",
			"0% EMI and discounts at listed merchants"
		]
	},
	signature: {
		name: "Visa Signature",
		short: "Signature",
		limit: "BDT 4 lac to 10 lac",
		fee: "BDT 5,000 a year",
		tone: "signature",
		feats: [
			"4 free international airport lounge visits a year, plus 2 Balaka Lounge visits",
			"Airport Meet and Greet with 3 companions",
			"Buy-one-get-one dining at Radisson Dhaka, Radisson Chittagong, InterContinental Dhaka and other partners",
			"Offers at partner merchants such as Aarong"
		]
	},
	plus: {
		name: "Visa Signature Plus",
		short: "Signature Plus",
		limit: "BDT 5 lac to 10 lac",
		fee: "BDT 12,000 a year",
		tone: "plus",
		feats: [
			"Up to 12 free international airport lounge visits a year",
			"8 complimentary airport pick-and-drop services",
			"Annual health check-up on BDT 4 lac yearly POS and e-commerce spend",
			"Buy-one-get-1/2/3 free buffet offers at leading hotels"
		]
	},
	sena: {
		name: "TBL SENA Card",
		short: "SENA",
		limit: "Set by your rank",
		fee: "No issuance fee",
		tone: "sena",
		feats: [
			"For serving JCOs and NCOs of the armed forces",
			"Renewal fee waived after 18 POS or e-commerce transactions",
			"Pre-approved limit based on your rank, with no debt-burden calculation",
			"A higher limit, up to twice your salary, may be possible with a satisfactory debt-burden ratio",
			"Only 3 documents: NID, e-TIN with return slip, and office ID card"
		]
	}
};
var RANKS = [
	{
		id: "sainik",
		label: "Sainik",
		cards: { sena: "" }
	},
	{
		id: "lcpl",
		label: "Lance Corporal",
		cards: { sena: "" }
	},
	{
		id: "cpl",
		label: "Corporal",
		cards: { sena: "" }
	},
	{
		id: "sgt",
		label: "Sergeant",
		cards: { sena: "" }
	},
	{
		id: "wo",
		label: "Warrant Officer (JCO)",
		cards: { sena: "" }
	},
	{
		id: "swo",
		label: "Senior Warrant Officer",
		cards: { sena: "" }
	},
	{
		id: "mwo",
		label: "Master Warrant Officer / Honorary Captain",
		cards: { sena: "" }
	},
	{
		id: "lt",
		label: "Lieutenant",
		cards: { gold: "BDT 2 lac" }
	},
	{
		id: "capt",
		label: "Captain",
		cards: { gold: "BDT 3 lac" }
	},
	{
		id: "major",
		label: "Major",
		cards: { platinum: "BDT 4 lac" }
	},
	{
		id: "ltcol",
		label: "Lieutenant Colonel",
		cards: { platinum: "BDT 4 lac" }
	},
	{
		id: "col",
		label: "Colonel",
		cards: {
			platinum: "BDT 4 lac",
			signature: "up to BDT 8 lac"
		}
	},
	{
		id: "brig",
		label: "Brigadier General or above",
		cards: {
			platinum: "up to BDT 5 lac",
			signature: "up to BDT 10 lac"
		}
	}
];
var CIVIL_ORDER = [
	"signature",
	"platinum",
	"gold",
	"classic"
];
var DEFENCE_ORDER = [
	"signature",
	"platinum",
	"gold",
	"sena"
];
var GLANCE_ROWS = [
	{
		card: "Classic",
		limit: "Up to BDT 1.2 lac",
		fee: "BDT 1,000",
		govt: "15,000",
		private: "30,000",
		biz: "40,000"
	},
	{
		card: "Gold",
		limit: "BDT 1.2 to 5 lac",
		fee: "BDT 2,000",
		govt: "15,000",
		private: "30,000",
		biz: "40,000"
	},
	{
		card: "Platinum",
		limit: "BDT 2 to 5 lac",
		fee: "BDT 3,000",
		govt: "50,000",
		private: "1,00,000",
		biz: "1,50,000"
	},
	{
		card: "Signature",
		limit: "BDT 4 to 10 lac",
		fee: "BDT 5,000",
		govt: "1,00,000",
		private: "1,50,000",
		biz: "2,00,000"
	},
	{
		card: "SENA",
		limit: "Set by rank",
		fee: "No issuance fee",
		note: "For serving JCOs and NCOs of the armed forces"
	}
];
var FAQS = [
	{
		q: "Will meeting the minimum get me the card?",
		a: "Not automatically. This page gives you a quick, informal read. Your officer still confirms your income, experience and CIB report before approving a card and setting your final limit."
	},
	{
		q: "What is a CIB report, and why does tax filing matter?",
		a: "CIB is Bangladesh Bank's record of your loans and card dues; a clear report is required. A valid e-TIN and last year's tax return are also required for a credit card, so it's worth sorting out before you apply if you haven't already."
	},
	{
		q: "How long is the interest-free period?",
		a: "Up to 45 days on purchases, when you pay the full statement amount by the due date. Cash withdrawals do not get an interest-free period."
	},
	{
		q: "How can I avoid the annual fee?",
		a: "On Classic, Gold, Platinum and Signature, it's waived from the second year after 18 POS or e-commerce transactions. The SENA card waives its renewal fee the same way."
	},
	{
		q: "Can my family have cards too?",
		a: "Yes. You can add up to 4 supplementary cards, and the first one is free."
	},
	{
		q: "I'm not there yet. What can I do?",
		a: "Check the note on each card above. You can also ask about a card secured against a fixed deposit (FDR), or apply again once your income or experience reaches the minimum."
	},
	{
		q: "What happens to what I type here?",
		a: "Nothing is stored by this page. If you fill in your details and press “Send my details,” your own email and WhatsApp app open with a message already addressed to the officer named above — you review and send it yourself."
	}
];
var OCC_OPTIONS = [
	{
		value: "govt",
		title: "Government job",
		sub: "Or semi-government"
	},
	{
		value: "private",
		title: "Private job",
		sub: "Company, bank, NBFI, MNC"
	},
	{
		value: "self",
		title: "Own business",
		sub: "Or landlord"
	},
	{
		value: "defence",
		title: "Armed forces",
		sub: "Serving personnel"
	}
];
var CALL_TIMES = [
	"Any time",
	"Morning (9 am to 12 pm)",
	"Afternoon (12 pm to 4 pm)",
	"Evening (4 pm to 7 pm)"
];
var OCC_LABELS = {
	govt: "Government / semi-government job",
	private: "Private job",
	self: "Own business or landlord",
	defence: "Armed forces"
};
var NF = new Intl.NumberFormat("en-IN");
function fmt(n) {
	return NF.format(n);
}
function findRank(id) {
	return RANKS.find((r) => r.id === id) ?? null;
}
function groupOf(occ) {
	return occ === "govt" ? "govt" : occ === "private" ? "private" : "self";
}
function isCivil(occ) {
	return occ === "govt" || occ === "private" || occ === "self";
}
function isStarted(s) {
	return !!s.occ;
}
function cardOrder(occ) {
	return occ === "defence" ? DEFENCE_ORDER : CIVIL_ORDER;
}
function evalCivil(cardId, s) {
	const g = groupOf(s.occ);
	const thresh = RULES[cardId].inc[g];
	const blockers = [];
	const unknown = [];
	const caveats = [];
	if (s.occ === "self") {
		if (s.biz === "no") blockers.push({ type: "biz" });
		else if (s.biz === "") unknown.push("biz");
	}
	if (s.income > 0) {
		if (s.income < thresh) blockers.push({
			type: "income",
			need: thresh
		});
	} else unknown.push("income");
	if (s.tenure === "no") blockers.push({ type: "tenure" });
	else if (s.tenure === "") unknown.push("tenure");
	if (cardId === "platinum" || cardId === "signature") caveats.push(`Your officer will confirm you meet the full experience requirement: ${RULES[cardId].ten}`);
	if (s.tax === "no") caveats.push("You will need a valid e-TIN and last year’s tax return on file before applying.");
	else if (s.tax === "unsure") caveats.push("A valid e-TIN and tax return on file are required — check this before applying.");
	return {
		status: blockers.length ? "no" : unknown.length ? "partial" : "ok",
		blockers,
		unknown,
		caveats,
		thresh
	};
}
function evalDefence(cardId, s) {
	if (!s.rank) return {
		status: "partial",
		blockers: [],
		unknown: ["rank"],
		caveats: []
	};
	const rk = findRank(s.rank);
	const has = !!rk && Object.prototype.hasOwnProperty.call(rk.cards, cardId);
	return {
		status: has ? "ok" : "no",
		blockers: has ? [] : [{ type: "rank" }],
		unknown: [],
		caveats: [],
		limitNote: has ? rk.cards[cardId] : ""
	};
}
function evalCard(cardId, s) {
	if (cardId === "plus") return {
		status: "partial",
		blockers: [],
		unknown: [],
		caveats: []
	};
	return s.occ === "defence" ? evalDefence(cardId, s) : evalCivil(cardId, s);
}
function bestOf(s) {
	if (!s.occ) return "";
	for (const id of cardOrder(s.occ)) if (evalCard(id, s).status === "ok") return id;
	return "";
}
function reasonText(b, s) {
	if (b.type === "income") return `Needs BDT ${fmt(b.need)} or more a month. You entered BDT ${fmt(s.income)}.`;
	if (b.type === "tenure") return "Needs at least 3 months in your current role or business.";
	if (b.type === "biz") return "Doesn’t yet meet our minimum business-owner requirement (see question 1).";
	if (b.type === "rank") return "This card is not offered for your rank.";
	return "";
}
function unknownText(u) {
	if (u === "income") return "Tell us your monthly income to check this.";
	if (u === "tenure") return "Tell us if you’ve been in your role at least 3 months.";
	if (u === "biz") return "Tell us if you meet our minimum business requirement.";
	if (u === "rank") return "Choose your rank to check this.";
	return "";
}
function minText(cardId, s) {
	if (s.occ === "defence") return "Rank-based limit. Final limit is confirmed by the bank.";
	if (cardId === "plus" || cardId === "sena") return CARDS[cardId].limit;
	const r = RULES[cardId];
	return `Minimum monthly income: government job BDT ${fmt(r.inc.govt)}, private job BDT ${fmt(r.inc.private)}, business BDT ${fmt(r.inc.self)}. ${r.ten}`;
}
function docsFor(s, cardId) {
	if (s.occ === "defence") {
		if (cardId === "sena") return [
			{ t: "NID photocopy" },
			{ t: "e-TIN certificate with tax acknowledgement return slip" },
			{ t: "Office ID card photocopy" }
		];
		return [
			{ t: "Duly filled application form" },
			{ t: "One passport-size photograph" },
			{ t: "e-TIN certificate" },
			{ t: "NID copy" },
			{ t: "Office ID card photocopy" },
			{ t: "Passport copy, if you want a dual-currency card" },
			{ t: "Signed CIB undertaking form" }
		];
	}
	const D = [
		{ t: "Duly filled application form" },
		{ t: "One passport-size photograph" },
		{ t: "NID copy" },
		{ t: "e-TIN certificate with your latest tax return" },
		{ t: "Recent utility bill copy, for address verification" },
		{ t: "Signed CIB undertaking form" }
	];
	if (s.occ === "self") {
		D.push({ t: "Trade licence, or partnership/company registration documents, whichever fits your business" });
		D.push({ t: "Last 12 months business bank statement" });
		D.push({
			t: "Contact point verification and income visit report",
			bank: true
		});
	} else {
		D.push({ t: "Office ID card photocopy" });
		D.push({ t: "Salary certificate, letter of introduction (LOI) or pay slip" });
		D.push({ t: "Bank statement for the last 6 months" });
	}
	return D;
}
function currentDocsCard(s, best) {
	return s.selected || best || (s.occ === "defence" ? "sena" : "classic");
}
function qualifiesNames(s) {
	if (!s.occ) return [];
	return cardOrder(s.occ).filter((id) => evalCard(id, s).status === "ok").map((id) => CARDS[id].name);
}
var BD_MOBILE = /^(\+?88)?01[3-9][0-9]{8}$/;
var EMAIL_OK = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
var useQuiz = create((set) => ({
	occ: "",
	income: 0,
	tenure: "",
	tax: "",
	biz: "",
	rank: "",
	selected: "",
	open: {},
	autoOpened: false,
	ticked: {},
	tab: "you",
	helpOpen: false,
	setOcc: (occ) => set({
		occ,
		autoOpened: false,
		selected: "",
		open: {}
	}),
	setIncome: (income) => set({ income }),
	setTenure: (tenure) => set({ tenure }),
	setTax: (tax) => set({ tax }),
	setBiz: (biz) => set({ biz }),
	setRank: (rank) => set({
		rank,
		autoOpened: false
	}),
	setSelected: (selected) => set({
		selected,
		tab: "docs"
	}),
	toggleOpen: (id, open) => set((s) => ({ open: {
		...s.open,
		[id]: open
	} })),
	markAutoOpened: (id) => set((s) => ({
		autoOpened: true,
		open: {
			...s.open,
			[id]: true
		}
	})),
	setTicked: (label, on) => set((s) => ({ ticked: {
		...s.ticked,
		[label]: on
	} })),
	setTab: (tab) => set({
		tab,
		helpOpen: false
	}),
	setHelpOpen: (helpOpen) => set({ helpOpen })
}));
var ICONS = {
	govt: Landmark,
	private: Briefcase,
	self: Store,
	defence: Shield
};
function AboutYou() {
	const occ = useQuiz((s) => s.occ);
	const income = useQuiz((s) => s.income);
	const tenure = useQuiz((s) => s.tenure);
	const tax = useQuiz((s) => s.tax);
	const biz = useQuiz((s) => s.biz);
	const rank = useQuiz((s) => s.rank);
	const setOcc = useQuiz((s) => s.setOcc);
	const setIncome = useQuiz((s) => s.setIncome);
	const setTenure = useQuiz((s) => s.setTenure);
	const setTax = useQuiz((s) => s.setTax);
	const setBiz = useQuiz((s) => s.setBiz);
	const setRank = useQuiz((s) => s.setRank);
	const setTab = useQuiz((s) => s.setTab);
	const civil = isCivil(occ);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.16em] text-brand uppercase",
					children: "Step 1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-[28px] font-semibold leading-tight text-brand-deep text-balance",
					children: "Which credit card fits you?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-[15px] leading-relaxed text-lede text-pretty",
					children: "Answer a few quick questions and see what each Trust Bank card offers, and where you stand. Nothing is required beyond your name and number — skip anything you're unsure of."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border border-line bg-surface-warm px-3 py-2.5 text-[13px] leading-snug text-muted",
				children: "Nothing here is saved. When you send your details, your own email and WhatsApp open, pre-filled and addressed to a Trust Bank officer — you review and send it yourself."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-4 shadow-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "mb-2.5 text-[15px] font-bold text-ink",
						children: "Where does your income come from?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: OCC_OPTIONS.map((opt) => {
							const Icon = ICONS[opt.value];
							const on = occ === opt.value;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setOcc(opt.value),
								className: cn("flex min-h-20 flex-col items-start gap-1 rounded-xl border-2 px-3 py-2.5 text-left transition-colors duration-fast ease-smooth", on ? "border-gold bg-gold-soft" : "border-line bg-bg hover:border-gold/50"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: cn("size-4", on ? "text-gold" : "text-brand"),
										strokeWidth: 2
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[14px] font-bold leading-tight text-ink",
										children: opt.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[12px] leading-tight text-muted",
										children: opt.sub
									})
								]
							}, opt.value);
						})
					})] }),
					civil ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								htmlFor: "income",
								className: "mb-1.5 block text-[14px] font-bold text-ink",
								children: ["Monthly income ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-normal text-muted",
									children: "(optional)"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex items-center rounded-l-lg border border-r-0 border-line bg-bg-soft px-3 text-[13px] font-bold text-muted",
									children: "BDT"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "income",
									type: "text",
									inputMode: "numeric",
									autoComplete: "off",
									placeholder: "e.g. 45,000",
									value: income ? fmt(income) : "",
									onChange: (e) => {
										const d = e.target.value.replace(/[^0-9]/g, "").slice(0, 9);
										setIncome(d ? parseInt(d, 10) : 0);
									},
									className: "min-h-12 w-full rounded-r-lg border border-line bg-bg px-3 text-lg tabular-nums text-ink outline-none focus-visible:ring-2 focus-visible:ring-gold"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex flex-wrap gap-1.5",
								"aria-label": "Quick amounts",
								children: INCOME_CHIPS.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setIncome(v),
									className: cn("min-h-9 rounded-full border px-3 text-[13px] font-semibold tabular-nums", income === v ? "border-brand bg-brand-soft text-brand-deep" : "border-line bg-surface text-ink hover:border-gold"),
									children: fmt(v)
								}, v))
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-1.5 text-[14px] font-bold text-ink",
							children: [
								"Have you been in this role for at least 3 months?",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-normal text-muted",
									children: "(optional)"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: [["yes", "Yes"], ["no", "Not yet"]].map(([val, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setTenure(val),
								className: cn("flex min-h-11 flex-1 items-center justify-center rounded-lg border-2 px-3 text-[14px] font-semibold", tenure === val ? "border-brand bg-brand-soft text-brand-deep" : "border-line bg-bg text-ink"),
								children: label
							}, val))
						})]
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-1.5 text-[14px] font-bold text-ink",
							children: [
								"Did you submit an income tax return (e-TIN) last year?",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-normal text-muted",
									children: "(optional)"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: [
								["yes", "Yes"],
								["no", "No"],
								["unsure", "Not sure"]
							].map(([val, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setTax(val),
								className: cn("flex min-h-11 flex-1 items-center justify-center rounded-lg border-2 px-2 text-[13px] font-semibold", tax === val ? "border-brand bg-brand-soft text-brand-deep" : "border-line bg-bg text-ink"),
								children: label
							}, val))
						})]
					}),
					occ === "self" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-1 text-[14px] font-bold text-ink",
								children: [
									"Do you meet our usual minimum for a business owner?",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-normal text-muted",
										children: "(optional)"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-[13px] leading-snug text-muted",
								children: "Generally: average monthly income of BDT 40,000 or more, and a trade licence at least 2 years old. Higher-value cards ask for more — your officer can confirm the exact figures."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2",
								children: [["yes", "Yes, I meet this"], ["no", "Not yet"]].map(([val, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setBiz(val),
									className: cn("flex min-h-11 flex-1 items-center justify-center rounded-lg border-2 px-3 text-center text-[13px] font-semibold", biz === val ? "border-brand bg-brand-soft text-brand-deep" : "border-line bg-bg text-ink"),
									children: label
								}, val))
							})
						]
					}) : null,
					occ === "defence" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								htmlFor: "rank",
								className: "mb-1.5 block text-[14px] font-bold text-ink",
								children: ["Your rank ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-normal text-muted",
									children: "(optional)"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								id: "rank",
								value: rank,
								onChange: (e) => setRank(e.target.value),
								className: "min-h-12 w-full rounded-lg border border-line bg-bg px-3 text-[15px] text-ink outline-none focus-visible:ring-2 focus-visible:ring-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Choose your rank"
								}), RANKS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: r.id,
									children: r.label
								}, r.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1.5 text-[13px] text-muted",
								children: "Or the equivalent rank in the Navy or Air Force. Limits are set by rank; no income calculation is needed."
							})
						]
					}) : null
				]
			}),
			occ ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab("cards"),
				className: "min-h-12 rounded-xl bg-brand px-5 text-[16px] font-bold text-white shadow-border active:scale-[0.99]",
				children: "See your cards"
			}) : null
		]
	});
}
var TONES = {
	classic: "from-brand to-brand-deep text-white",
	gold: "from-gold to-gold-deep text-white",
	platinum: "from-platinum to-brand-deep text-white",
	signature: "from-brand-deep to-ink text-gold-soft",
	plus: "from-ink to-brand-deep text-gold-soft",
	sena: "from-sena to-brand-deep text-white"
};
function PlasticCard({ name, limit, tone, compact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative overflow-hidden rounded-xl bg-linear-to-br shadow-card", TONES[tone], compact ? "aspect-card px-3.5 py-3" : "aspect-card px-4 py-3.5"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-6 -top-8 size-28 rounded-full bg-white/10" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -bottom-10 -left-8 size-32 rounded-full bg-black/10" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex h-full flex-col justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/tbl-mark.svg",
						alt: "",
						className: "h-8 w-8 object-contain drop-shadow-sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-semibold tracking-[0.18em] uppercase opacity-80",
						children: "Trust Bank"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-display text-[15px] font-semibold leading-tight",
							children: name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-[11px] font-medium opacity-80",
							children: limit
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 text-[11px] font-bold tracking-widest opacity-90",
						children: "VISA"
					})]
				})]
			})
		]
	});
}
function Rung({ id, best }) {
	const occ = useQuiz((s) => s.occ);
	const income = useQuiz((s) => s.income);
	const tenure = useQuiz((s) => s.tenure);
	const tax = useQuiz((s) => s.tax);
	const biz = useQuiz((s) => s.biz);
	const rank = useQuiz((s) => s.rank);
	const selected = useQuiz((s) => s.selected);
	const open = useQuiz((s) => s.open[id] ?? false);
	const toggleOpen = useQuiz((s) => s.toggleOpen);
	const setSelected = useQuiz((s) => s.setSelected);
	const slice = {
		occ,
		income,
		tenure,
		tax,
		biz,
		rank
	};
	const c = CARDS[id];
	const r = id === "plus" ? null : evalCard(id, slice);
	const isBest = r?.status === "ok" && id === best;
	let status = "";
	if (id === "plus") status = "info";
	else if (r) status = r.status;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("overflow-hidden rounded-2xl border bg-surface shadow-border", status === "ok" && "border-l-4 border-l-brand", isBest && "border-brand ring-1 ring-brand", status === "partial" && "border-l-4 border-l-gold", status === "no" && "border-l-4 border-l-warn", status === "info" && "border-l-4 border-l-muted bg-surface-warm", status === "" && "border-line"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "flex w-full items-center gap-3 px-3.5 py-3 text-left",
			onClick: () => toggleOpen(id, !open),
			"aria-expanded": open,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-28 shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlasticCard, {
						name: c.short,
						limit: c.limit,
						tone: c.tone,
						compact: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [
						isBest ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-0.5 block text-[11px] font-bold text-brand",
							children: "Best match"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-[16px] font-semibold leading-tight text-ink",
							children: c.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-0.5 block text-[12.5px] leading-snug text-muted",
							children: [
								c.limit,
								" · ",
								c.fee
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex shrink-0 flex-col items-end gap-2",
					children: [
						status === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-brand px-2 py-0.5 text-[11px] font-bold text-white",
							children: "You qualify"
						}) : null,
						status === "partial" && id !== "plus" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-gold-line bg-gold-soft px-2 py-0.5 text-[11px] font-bold text-gold",
							children: "Tell us more"
						}) : null,
						status === "no" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-warn bg-warn-soft px-2 py-0.5 text-[11px] font-bold text-warn",
							children: "Not yet"
						}) : null,
						status === "info" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-line bg-bg px-2 py-0.5 text-[11px] font-bold text-muted",
							children: "Ask our team"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-5 text-gold transition-transform duration-fast", open && "rotate-180") })
					]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-line px-3.5 pb-4 pt-3",
			children: [
				id === "plus" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-lg bg-bg-soft px-3 py-2 text-[13.5px] text-ink",
					children: "Eligibility for this card is confirmed by the bank when you apply."
				}) : occ === "defence" && r?.status === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-lg bg-bg-soft px-3 py-2 text-[13.5px] text-ink",
					children: [r.limitNote ? `Limit for your rank: ${r.limitNote}. ` : "", "Final limit is confirmed by the bank."]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-lg bg-bg-soft px-3 py-2 text-[13.5px] text-ink",
					children: minText(id, slice)
				}),
				r?.status === "no" && r.blockers.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 list-disc rounded-lg bg-warn-soft px-7 py-2 text-[13.5px] text-ink",
					children: r.blockers.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: reasonText(b, slice) }, b.type))
				}) : null,
				r?.status === "partial" && r.unknown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 list-disc rounded-lg bg-warn-soft px-7 py-2 text-[13.5px] text-ink",
					children: r.unknown.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: unknownText(u) }, u))
				}) : null,
				r?.status === "ok" && r.caveats.length ? r.caveats.map((cv) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 rounded-lg bg-gold-soft px-3 py-2 text-[13.5px] text-caveat",
					children: cv
				}, cv)) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-3 text-[14px] font-bold text-brand",
					children: "What you get"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-1.5 list-disc space-y-1 pl-5 text-[14px] text-ink",
					children: c.feats.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: f }, f))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-[13px] text-muted",
					children: [
						"Credit limit: ",
						c.limit,
						". Annual fee: ",
						c.fee,
						", before 15% VAT."
					]
				}),
				r?.status === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSelected(id),
					className: "mt-3 min-h-10 rounded-lg bg-brand px-4 text-[14px] font-bold text-white",
					children: selected === id ? "Selected — see documents" : "Choose this card"
				}) : null
			]
		}) : null]
	});
}
function CardLadder() {
	const occ = useQuiz((s) => s.occ);
	const income = useQuiz((s) => s.income);
	const tenure = useQuiz((s) => s.tenure);
	const tax = useQuiz((s) => s.tax);
	const biz = useQuiz((s) => s.biz);
	const rank = useQuiz((s) => s.rank);
	const autoOpened = useQuiz((s) => s.autoOpened);
	const selected = useQuiz((s) => s.selected);
	const markAutoOpened = useQuiz((s) => s.markAutoOpened);
	const slice = {
		occ,
		income,
		tenure,
		tax,
		biz,
		rank
	};
	const best = bestOf(slice);
	const started = isStarted(slice);
	(0, import_react.useEffect)(() => {
		if (!autoOpened && best) markAutoOpened(best);
	}, [
		autoOpened,
		best,
		markAutoOpened
	]);
	(0, import_react.useEffect)(() => {
		if (!selected) return;
		if (evalCard(selected, {
			occ,
			income,
			tenure,
			tax,
			biz,
			rank
		}).status !== "ok") useQuiz.setState({ selected: "" });
	}, [
		selected,
		occ,
		income,
		tenure,
		tax,
		biz,
		rank
	]);
	const order = started ? [...cardOrder(occ), "plus"] : CIVIL_WITH_PLUS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.16em] text-brand uppercase",
				children: "Step 2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-[24px] font-semibold leading-tight text-brand-deep text-balance",
				children: "Our cards, and where you stand"
			}),
			!started ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-[14px] text-muted",
				children: "Tap any card to see its features and minimum requirements. Answer question 1 to see where you stand on each."
			}) : best ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-[14px] text-lede",
				children: [
					"Best match: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-bold text-brand",
						children: CARDS[best].name
					}),
					". Tap a card for features."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-[14px] text-lede",
				children: "Fill in a bit more on the You tab, or tap a card to see what it asks for."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-2.5",
			children: order.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rung, {
				id,
				best
			}, id))
		})]
	});
}
var CIVIL_WITH_PLUS = [
	"signature",
	"platinum",
	"gold",
	"classic",
	"plus"
];
function DocsList() {
	const occ = useQuiz((s) => s.occ);
	const income = useQuiz((s) => s.income);
	const tenure = useQuiz((s) => s.tenure);
	const tax = useQuiz((s) => s.tax);
	const biz = useQuiz((s) => s.biz);
	const rank = useQuiz((s) => s.rank);
	const selected = useQuiz((s) => s.selected);
	const ticked = useQuiz((s) => s.ticked);
	const setTicked = useQuiz((s) => s.setTicked);
	const setTab = useQuiz((s) => s.setTab);
	const slice = {
		occ,
		income,
		tenure,
		tax,
		biz,
		rank
	};
	const best = bestOf(slice);
	const started = isStarted(slice);
	const id = currentDocsCard({
		...slice,
		selected
	}, best);
	const list = docsFor(slice, id);
	const total = list.filter((d) => !d.bank).length;
	const done = list.filter((d) => !d.bank && ticked[d.t]).length;
	const pct = total ? Math.round(done * 100 / total) : 0;
	const sub = !started ? "" : selected ? "Tick what you already have." : best ? "Showing your best match. Choose another card to change it." : "You’re not at the minimum yet — this list is for the easiest card, so you can start preparing.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.16em] text-brand uppercase",
				children: "Step 3"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-[24px] font-semibold leading-tight text-brand-deep",
				children: "Documents to prepare"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-2xl bg-surface p-4 shadow-border",
				children: !started ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[14px] text-muted",
					children: "Answer question 1 to see your document list."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-[18px] font-semibold text-brand-deep",
						children: ["For ", CARDS[id].name]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-[13px] text-muted",
						children: sub
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-2.5 overflow-hidden rounded-md border border-line bg-bg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-brand transition-[width] duration-fast ease-smooth",
							style: { width: `${pct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-[13px] tabular-nums text-ink",
						children: [
							done,
							" of ",
							total,
							" ready"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-1.5",
						children: list.map((d) => {
							const on = !!ticked[d.t];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: cn("flex min-h-12 cursor-pointer items-start gap-2.5 rounded-xl border px-3 py-2.5", on ? "border-brand bg-brand-soft" : "border-line bg-bg"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: on,
									onChange: (e) => setTicked(d.t, e.target.checked),
									className: "mt-0.5 size-5 accent-brand"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[14px] leading-snug text-ink",
									children: [d.t, d.bank ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-1.5 inline-block rounded-full bg-brand-soft px-2 py-0.5 text-[11px] font-bold text-brand",
										children: "We arrange this"
									}) : null]
								})]
							}) }, d.t);
						})
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab("send"),
				className: "min-h-12 rounded-xl bg-brand px-5 text-[16px] font-bold text-white",
				children: "Send your details"
			})
		]
	});
}
function tenureLabel(v) {
	return v === "yes" ? "Yes" : v === "no" ? "Not yet" : "";
}
function taxLabel(v) {
	return v === "yes" ? "Yes" : v === "no" ? "No" : v === "unsure" ? "Not sure" : "";
}
function bizLabel(v) {
	return v === "yes" ? "Yes, meets it" : v === "no" ? "Not yet" : "";
}
function SendDetails() {
	const occ = useQuiz((s) => s.occ);
	const income = useQuiz((s) => s.income);
	const tenure = useQuiz((s) => s.tenure);
	const tax = useQuiz((s) => s.tax);
	const biz = useQuiz((s) => s.biz);
	const rank = useQuiz((s) => s.rank);
	const selected = useQuiz((s) => s.selected);
	const ticked = useQuiz((s) => s.ticked);
	const [name, setName] = (0, import_react.useState)("");
	const [mobile, setMobile] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [area, setArea] = (0, import_react.useState)("");
	const [time, setTime] = (0, import_react.useState)("Any time");
	const [consent, setConsent] = (0, import_react.useState)(false);
	const [errs, setErrs] = (0, import_react.useState)("");
	const [summary, setSummary] = (0, import_react.useState)("");
	const [mailHref, setMailHref] = (0, import_react.useState)("");
	const [waHref, setWaHref] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const slice = (0, import_react.useMemo)(() => ({
		occ,
		income,
		tenure,
		tax,
		biz,
		rank
	}), [
		occ,
		income,
		tenure,
		tax,
		biz,
		rank
	]);
	const best = bestOf(slice);
	function buildSummary() {
		const L = [];
		L.push("Trust Bank credit card enquiry (self-declared, subject to bank verification)");
		L.push(`To: ${OFFICER.name} — ${OFFICER.title}`);
		try {
			L.push(`Sent: ${(/* @__PURE__ */ new Date()).toLocaleString("en-GB", {
				dateStyle: "medium",
				timeStyle: "short"
			})}`);
		} catch {}
		L.push(`Name: ${name.trim()}`);
		L.push(`Mobile: ${mobile.trim()}`);
		if (email.trim()) L.push(`Email: ${email.trim()}`);
		if (area.trim()) L.push(`Nearest branch or area: ${area.trim()}`);
		L.push(`Best time to call: ${time}`);
		if (occ) {
			L.push(`Source of income: ${OCC_LABELS[occ]}`);
			if (occ === "defence") {
				const rk = findRank(rank);
				if (rk) L.push(`Rank: ${rk.label}`);
			} else {
				if (income) L.push(`Monthly income: BDT ${fmt(income)}`);
				if (tenure) L.push(`At least 3 months in role: ${tenureLabel(tenure)}`);
				if (occ === "self" && biz) L.push(`Meets minimum business requirement: ${bizLabel(biz)}`);
			}
			if (tax) L.push(`Tax return filed last year: ${taxLabel(tax)}`);
		}
		if (isStarted(slice)) {
			const qualifies = qualifiesNames(slice);
			const bestName = best ? CARDS[best].name : qualifies[0] ?? "";
			L.push(`ELIGIBILITY STATUS: ${qualifies.length ? `MEETS MINIMUM (best match: ${bestName})` : "NOT YET AT MINIMUM, OR NEEDS MORE INFO"}`);
			if (qualifies.length) L.push(`Qualifies for: ${qualifies.join(", ")}`);
			const id = currentDocsCard({
				...slice,
				selected
			}, best);
			L.push(`Interested in: ${CARDS[id].name}`);
			const list = docsFor(slice, id).filter((d) => !d.bank);
			const ready = list.filter((d) => ticked[d.t]);
			const todo = list.filter((d) => !ticked[d.t]);
			L.push(`Documents ready: ${ready.length} of ${list.length}`);
			if (todo.length) L.push(`Still to arrange: ${todo.map((d) => d.t).join("; ")}`);
		}
		return L.join("\n");
	}
	function send() {
		const errors = [];
		if (name.trim().length < 2) errors.push("Enter your full name.");
		const m2 = mobile.replace(/[\s-]/g, "");
		if (!BD_MOBILE.test(m2)) errors.push("Enter a valid mobile number, for example 01712345678.");
		if (email.trim() && !EMAIL_OK.test(email.trim())) errors.push("Check your email address.");
		if (!consent) errors.push("Tick the box to agree to be contacted.");
		if (errors.length) {
			setErrs(errors.join(" "));
			setSummary("");
			return;
		}
		setErrs("");
		const text = buildSummary();
		setSummary(text);
		const enc = encodeURIComponent(text);
		const eligTag = best ? "Eligible" : isStarted(slice) ? "Needs review" : "Enquiry";
		const subject = `Credit card enquiry — ${name.trim() || "New applicant"} — ${eligTag}`;
		const wa = `https://wa.me/${OFFICER.whatsapp}?text=${enc}`;
		const mail = `mailto:${OFFICER.email}?subject=${encodeURIComponent(subject)}&body=${enc}`;
		setWaHref(wa);
		setMailHref(mail);
		let waWin = null;
		try {
			waWin = window.open(wa, "_blank", "noopener");
		} catch {
			waWin = null;
		}
		try {
			window.open(mail, "_blank", "noopener");
		} catch {}
		const bits = [];
		if (!waWin) bits.push("If WhatsApp did not open, tap \"Open WhatsApp again\" below.");
		bits.push("If your email app did not open, tap \"Open email again\" below.");
		setStatus(`Sending to ${OFFICER.name}. ${bits.join(" ")}`);
	}
	async function copySummary() {
		try {
			await navigator.clipboard.writeText(summary);
			setCopied(true);
			setStatus("Copied. Paste it into WhatsApp, SMS or email.");
		} catch {
			setStatus("Press and hold the text above to copy it.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.16em] text-brand uppercase",
				children: "Step 4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-[24px] font-semibold leading-tight text-brand-deep",
				children: "Send your details"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-[14px] text-muted",
				children: "Only your name and number are required. Everything else helps us serve you faster."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-2xl bg-surface p-4 shadow-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Full name",
					htmlFor: "c-name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "c-name",
						autoComplete: "name",
						value: name,
						onChange: (e) => setName(e.target.value),
						className: "field-input"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Mobile number",
					htmlFor: "c-mobile",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "c-mobile",
						type: "tel",
						inputMode: "tel",
						autoComplete: "tel",
						placeholder: "01XXXXXXXXX",
						value: mobile,
						onChange: (e) => setMobile(e.target.value),
						className: "field-input"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email",
					htmlFor: "c-email",
					optional: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "c-email",
						type: "email",
						autoComplete: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						className: "field-input"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nearest branch or area",
					htmlFor: "c-area",
					optional: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "c-area",
						autoComplete: "off",
						placeholder: "e.g. Uttara, Dhaka",
						value: area,
						onChange: (e) => setArea(e.target.value),
						className: "field-input"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Best time to call",
					htmlFor: "c-time",
					optional: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						id: "c-time",
						value: time,
						onChange: (e) => setTime(e.target.value),
						className: "field-input",
						children: CALL_TIMES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 rounded-xl bg-brand-soft px-3 py-2.5 text-[13.5px] leading-snug text-ink",
					children: [
						"Your details go to ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: OFFICER.name }),
						", ",
						OFFICER.title,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 flex items-start gap-2.5 text-[13.5px] leading-snug text-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: consent,
						onChange: (e) => setConsent(e.target.checked),
						className: "mt-0.5 size-5 shrink-0 accent-brand"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I agree that Trust Bank may contact me about a credit card, and that sending this will open my email and WhatsApp app addressed to the officer above. My details are self-declared and will be verified by the bank." })]
				}),
				errs ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-[14px] font-semibold text-warn",
					role: "alert",
					children: errs
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: send,
					className: "mt-4 min-h-12 w-full rounded-xl bg-brand text-[16px] font-bold text-white",
					children: "Send my details"
				}),
				summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-[14px] font-bold text-brand",
							children: "Your summary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							readOnly: true,
							"aria-label": "Your summary",
							value: summary,
							className: "mt-2 min-h-44 w-full resize-y rounded-lg border border-line bg-bg p-3 text-[13.5px] leading-snug text-ink"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [
								mailHref ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: "inline-flex min-h-10 items-center gap-1.5 rounded-lg bg-brand px-3 text-[14px] font-bold text-white",
									href: mailHref,
									target: "_blank",
									rel: "noopener noreferrer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4" }), " Open email again"]
								}) : null,
								waHref ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: "inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-brand px-3 text-[14px] font-bold text-brand",
									href: waHref,
									target: "_blank",
									rel: "noopener noreferrer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), " Open WhatsApp again"]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: copySummary,
									className: "inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-brand px-3 text-[14px] font-bold text-brand",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }),
										" ",
										copied ? "Copied" : "Copy summary"
									]
								})
							]
						}),
						status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[13.5px] font-semibold text-brand",
							role: "status",
							children: status
						}) : null
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-brand px-3 text-[14px] font-bold text-brand",
						href: "tel:16201",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), " Call 16201"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-brand px-3 text-[14px] font-bold text-brand",
						href: "https://www.tblbd.com",
						target: "_blank",
						rel: "noopener noreferrer",
						children: "Visit tblbd.com"
					})]
				})
			]
		})]
	});
}
function Field({ label, htmlFor, optional, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 first:mt-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			htmlFor,
			className: "mb-1.5 block text-[14px] font-bold text-ink",
			children: [
				label,
				" ",
				optional ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-normal text-muted",
					children: "(optional)"
				}) : null
			]
		}), children]
	});
}
function HelpView() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.16em] text-brand uppercase",
				children: "Reference"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-[24px] font-semibold leading-tight text-brand-deep",
				children: "Minimum requirements at a glance"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-2xl bg-surface shadow-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "glance-table w-full border-collapse text-left text-[13px] leading-snug",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "bg-bg-soft text-[12.5px] font-bold text-brand-deep",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2.5 py-2",
								children: "Card"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2.5 py-2",
								children: "Credit limit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2.5 py-2",
								children: "Annual fee"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2.5 py-2",
								children: "Govt salary"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2.5 py-2",
								children: "Private salary"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-2.5 py-2",
								children: "Business income"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: GLANCE_ROWS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2.5 py-2 font-bold text-ink",
								children: row.card
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2.5 py-2",
								children: row.limit
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2.5 py-2 tabular-nums",
								children: row.fee
							}),
							"note" in row && row.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2.5 py-2",
								colSpan: 3,
								children: row.note
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2.5 py-2 tabular-nums",
									children: "govt" in row ? row.govt : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2.5 py-2 tabular-nums",
									children: "private" in row ? row.private : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2.5 py-2 tabular-nums",
									children: "biz" in row ? row.biz : ""
								})
							] })
						]
					}, row.card)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[13px] leading-relaxed text-muted",
				children: "Amounts are monthly, in BDT. Fees are before 15% VAT. Classic, Gold and SENA also need about a year of experience (or 2 years in business); Platinum and Signature need about 5 years. Meeting a minimum does not guarantee approval."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-[22px] font-semibold text-brand-deep",
				children: "Common questions"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-col gap-2",
				children: FAQS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "group rounded-2xl bg-surface shadow-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
						className: "flex cursor-pointer list-none items-center gap-2 px-4 py-3.5 text-[15px] font-bold text-ink [&::-webkit-details-marker]:hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1",
								children: f.q
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-xl text-gold group-open:hidden",
								children: "+"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden font-display text-xl text-gold group-open:inline",
								children: "–"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-4 pb-3.5 text-[14.5px] leading-relaxed text-lede",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: f.a })
					})]
				}, f.q))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-t border-line pt-4 text-[12.5px] leading-relaxed text-muted",
				children: "Figures are indicative and before 15% VAT. The bank's current schedule of charges and credit policy apply. Meeting a minimum does not guarantee approval. Never share your PIN, OTP or full card number with anyone."
			})
		]
	});
}
var TABS = [
	{
		id: "you",
		label: "You",
		icon: User
	},
	{
		id: "cards",
		label: "Cards",
		icon: CreditCard
	},
	{
		id: "docs",
		label: "Docs",
		icon: FileCheck
	},
	{
		id: "send",
		label: "Send",
		icon: Send
	}
];
var TITLES = {
	you: "TBL Cards",
	cards: "Your cards",
	docs: "Documents",
	send: "Send details"
};
function AndroidShell() {
	const tab = useQuiz((s) => s.tab);
	const setTab = useQuiz((s) => s.setTab);
	const helpOpen = useQuiz((s) => s.helpOpen);
	const setHelpOpen = useQuiz((s) => s.setHelpOpen);
	const occ = useQuiz((s) => s.occ);
	const income = useQuiz((s) => s.income);
	const tenure = useQuiz((s) => s.tenure);
	const tax = useQuiz((s) => s.tax);
	const biz = useQuiz((s) => s.biz);
	const rank = useQuiz((s) => s.rank);
	const started = isStarted({
		occ,
		income,
		tenure,
		tax,
		biz,
		rank
	});
	const best = bestOf({
		occ,
		income,
		tenure,
		tax,
		biz,
		rank
	});
	const [clock, setClock] = (0, import_react.useState)("09:41");
	(0, import_react.useEffect)(() => {
		const tick = () => setClock((/* @__PURE__ */ new Date()).toLocaleTimeString("en-GB", {
			hour: "2-digit",
			minute: "2-digit",
			hour12: false
		}));
		tick();
		const id = window.setInterval(tick, 3e4);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bezel md:flex md:items-center md:justify-center md:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "phone-shell",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "phone-notch",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-24 rounded-full bg-ink/80" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-10 bg-brand-deep text-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-7 items-center justify-between px-4 pt-safe text-[11px] font-semibold tabular-nums",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: clock }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5 opacity-90",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signal, { className: "size-3.5" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { className: "size-3.5" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Battery, { className: "size-3.5" })
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-14 items-center gap-2.5 px-3 pb-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/tbl-mark.svg",
								alt: "Trust Bank PLC",
								className: "h-9 w-9 object-contain"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-display text-[15px] font-semibold leading-tight",
									children: "Trust Bank PLC"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-[11px] leading-tight text-white/75",
									children: helpOpen ? "Help & requirements" : TITLES[tab]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setHelpOpen(!helpOpen),
								className: "flex size-11 items-center justify-center rounded-full text-white hover:bg-white/10",
								"aria-label": helpOpen ? "Close help" : "Help and requirements",
								children: helpOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, { className: "size-5" })
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 overflow-y-auto px-4 pt-4",
					children: helpOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpView, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						tab === "you" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutYou, {}) : null,
						tab === "cards" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardLadder, {}) : null,
						tab === "docs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocsList, {}) : null,
						tab === "send" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SendDetails, {}) : null
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "grid grid-cols-4 border-t border-line bg-surface pb-safe pt-1",
					"aria-label": "Primary",
					children: TABS.map((t) => {
						const Icon = t.icon;
						const on = !helpOpen && tab === t.id;
						const badge = t.id === "cards" && started && best;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTab(t.id),
							className: cn("relative flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold", on ? "text-brand" : "text-muted"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5",
									strokeWidth: on ? 2.4 : 2
								}),
								t.label,
								badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1.5 right-7 size-1.5 rounded-full bg-brand" }) : null
							]
						}, t.id);
					})
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AndroidShell, {});
}
//#endregion
export { Home as component };
