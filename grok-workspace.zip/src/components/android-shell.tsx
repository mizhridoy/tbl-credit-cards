import { useEffect, useState } from "react";
import { Battery, CircleHelp, CreditCard, FileCheck, Send, Signal, User, Wifi, X } from "lucide-react";
import { cn } from "@/lib/cn";
import { bestOf, isStarted } from "@/lib/eligibility";
import { useQuiz, type TabId } from "@/lib/store";
import { AboutYou } from "@/components/about-you";
import { CardLadder } from "@/components/card-ladder";
import { DocsList } from "@/components/docs-list";
import { SendDetails } from "@/components/send-details";
import { HelpView } from "@/components/help-view";

const TABS: { id: TabId; label: string; icon: typeof User }[] = [
  { id: "you", label: "You", icon: User },
  { id: "cards", label: "Cards", icon: CreditCard },
  { id: "docs", label: "Docs", icon: FileCheck },
  { id: "send", label: "Send", icon: Send },
];

const TITLES: Record<TabId, string> = {
  you: "TBL Cards",
  cards: "Your cards",
  docs: "Documents",
  send: "Send details",
};

export function AndroidShell() {
  const tab = useQuiz((s) => s.tab);
  const setTab = useQuiz((s) => s.setTab);
  const helpOpen = useQuiz((s) => s.helpOpen);
  const setHelpOpen = useQuiz((s) => s.setHelpOpen);
  const occ = useQuiz((s) => s.occ);
  const income = useQuiz((s) => s.income);
  const tenure = useQuiz((s) => s.tenure);
  const tax = useQuiz((s) => s.tax);
  const biz = useQuiz((s) => s.biz);
  const rank = useQuiz((s) => s.rank);
  const started = isStarted({ occ, income, tenure, tax, biz, rank });
  const best = bestOf({ occ, income, tenure, tax, biz, rank });

  const [clock, setClock] = useState("09:41");
  useEffect(() => {
    const tick = () =>
      setClock(
        new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false }),
      );
    tick();
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="min-h-dvh bg-bezel md:flex md:items-center md:justify-center md:p-6">
      <div className="phone-shell">
        <div className="phone-notch">
          <div className="h-5 w-24 rounded-full bg-ink/80" />
        </div>

        <header className="sticky top-0 z-10 bg-brand-deep text-white">
          <div className="flex h-7 items-center justify-between px-4 pt-safe text-[11px] font-semibold tabular-nums">
            <span>{clock}</span>
            <span className="flex items-center gap-1.5 opacity-90">
              <Signal className="size-3.5" />
              <Wifi className="size-3.5" />
              <Battery className="size-3.5" />
            </span>
          </div>
          <div className="flex h-14 items-center gap-2.5 px-3 pb-1">
            <img src="/tbl-mark.svg" alt="Trust Bank PLC" className="h-9 w-9 object-contain" />
            <div className="min-w-0 flex-1">
              <p className="truncate font-display text-[15px] font-semibold leading-tight">
                Trust Bank PLC
              </p>
              <p className="truncate text-[11px] leading-tight text-white/75">
                {helpOpen ? "Help & requirements" : TITLES[tab]}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setHelpOpen(!helpOpen)}
              className="flex size-11 items-center justify-center rounded-full text-white hover:bg-white/10"
              aria-label={helpOpen ? "Close help" : "Help and requirements"}
            >
              {helpOpen ? <X className="size-5" /> : <CircleHelp className="size-5" />}
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto px-4 pt-4">
          {helpOpen ? (
            <HelpView />
          ) : (
            <>
              {tab === "you" ? <AboutYou /> : null}
              {tab === "cards" ? <CardLadder /> : null}
              {tab === "docs" ? <DocsList /> : null}
              {tab === "send" ? <SendDetails /> : null}
            </>
          )}
        </main>

        <nav
          className="grid grid-cols-4 border-t border-line bg-surface pb-safe pt-1"
          aria-label="Primary"
        >
          {TABS.map((t) => {
            const Icon = t.icon;
            const on = !helpOpen && tab === t.id;
            const badge = t.id === "cards" && started && best;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={cn(
                  "relative flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold",
                  on ? "text-brand" : "text-muted",
                )}
              >
                <Icon className="size-5" strokeWidth={on ? 2.4 : 2} />
                {t.label}
                {badge ? <span className="absolute top-1.5 right-7 size-1.5 rounded-full bg-brand" /> : null}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
