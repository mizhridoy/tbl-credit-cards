import { Landmark, Briefcase, Store, Shield } from "lucide-react";
import { cn } from "@/lib/cn";
import { INCOME_CHIPS, OCC_OPTIONS, RANKS } from "@/lib/tbl-data";
import { fmt, isCivil } from "@/lib/eligibility";
import { useQuiz } from "@/lib/store";
import type { Occupancy } from "@/lib/tbl-data";

const ICONS = {
  govt: Landmark,
  private: Briefcase,
  self: Store,
  defence: Shield,
} as const;

export function AboutYou() {
  const occ = useQuiz((s) => s.occ);
  const income = useQuiz((s) => s.income);
  const tenure = useQuiz((s) => s.tenure);
  const tax = useQuiz((s) => s.tax);
  const biz = useQuiz((s) => s.biz);
  const rank = useQuiz((s) => s.rank);
  const setOcc = useQuiz((s) => s.setOcc);
  const setIncome = useQuiz((s) => s.setIncome);
  const setTenure = useQuiz((s) => s.setTenure);
  const setTax = useQuiz((s) => s.setTax);
  const setBiz = useQuiz((s) => s.setBiz);
  const setRank = useQuiz((s) => s.setRank);
  const setTab = useQuiz((s) => s.setTab);

  const civil = isCivil(occ);

  return (
    <div className="flex flex-col gap-5 pb-8">
      <header>
        <p className="text-xs font-semibold tracking-[0.16em] text-brand uppercase">Step 1</p>
        <h1 className="mt-1 font-display text-[28px] font-semibold leading-tight text-brand-deep text-balance">
          Which credit card fits you?
        </h1>
        <p className="mt-2 text-[15px] leading-relaxed text-lede text-pretty">
          Answer a few quick questions and see what each Trust Bank card offers, and where you stand.
          Nothing is required beyond your name and number — skip anything you're unsure of.
        </p>
      </header>

      <p className="rounded-lg border border-line bg-surface-warm px-3 py-2.5 text-[13px] leading-snug text-muted">
        Nothing here is saved. When you send your details, your own email and WhatsApp open, pre-filled
        and addressed to a Trust Bank officer — you review and send it yourself.
      </p>

      <section className="rounded-2xl bg-surface p-4 shadow-border">
        <fieldset>
          <legend className="mb-2.5 text-[15px] font-bold text-ink">Where does your income come from?</legend>
          <div className="grid grid-cols-2 gap-2">
            {OCC_OPTIONS.map((opt) => {
              const Icon = ICONS[opt.value];
              const on = occ === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setOcc(opt.value as Exclude<Occupancy, "">)}
                  className={cn(
                    "flex min-h-20 flex-col items-start gap-1 rounded-xl border-2 px-3 py-2.5 text-left transition-colors duration-fast ease-smooth",
                    on
                      ? "border-gold bg-gold-soft"
                      : "border-line bg-bg hover:border-gold/50",
                  )}
                >
                  <Icon className={cn("size-4", on ? "text-gold" : "text-brand")} strokeWidth={2} />
                  <span className="text-[14px] font-bold leading-tight text-ink">{opt.title}</span>
                  <span className="text-[12px] leading-tight text-muted">{opt.sub}</span>
                </button>
              );
            })}
          </div>
        </fieldset>

        {civil ? (
          <>
            <div className="mt-5">
              <label htmlFor="income" className="mb-1.5 block text-[14px] font-bold text-ink">
                Monthly income <span className="font-normal text-muted">(optional)</span>
              </label>
              <div className="flex">
                <span className="flex items-center rounded-l-lg border border-r-0 border-line bg-bg-soft px-3 text-[13px] font-bold text-muted">
                  BDT
                </span>
                <input
                  id="income"
                  type="text"
                  inputMode="numeric"
                  autoComplete="off"
                  placeholder="e.g. 45,000"
                  value={income ? fmt(income) : ""}
                  onChange={(e) => {
                    const d = e.target.value.replace(/[^0-9]/g, "").slice(0, 9);
                    setIncome(d ? parseInt(d, 10) : 0);
                  }}
                  className="min-h-12 w-full rounded-r-lg border border-line bg-bg px-3 text-lg tabular-nums text-ink outline-none focus-visible:ring-2 focus-visible:ring-gold"
                />
              </div>
              <div className="mt-2 flex flex-wrap gap-1.5" aria-label="Quick amounts">
                {INCOME_CHIPS.map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setIncome(v)}
                    className={cn(
                      "min-h-9 rounded-full border px-3 text-[13px] font-semibold tabular-nums",
                      income === v
                        ? "border-brand bg-brand-soft text-brand-deep"
                        : "border-line bg-surface text-ink hover:border-gold",
                    )}
                  >
                    {fmt(v)}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5">
              <p className="mb-1.5 text-[14px] font-bold text-ink">
                Have you been in this role for at least 3 months?{" "}
                <span className="font-normal text-muted">(optional)</span>
              </p>
              <div className="flex gap-2">
                {(
                  [
                    ["yes", "Yes"],
                    ["no", "Not yet"],
                  ] as const
                ).map(([val, label]) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setTenure(val)}
                    className={cn(
                      "flex min-h-11 flex-1 items-center justify-center rounded-lg border-2 px-3 text-[14px] font-semibold",
                      tenure === val
                        ? "border-brand bg-brand-soft text-brand-deep"
                        : "border-line bg-bg text-ink",
                    )}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </>
        ) : null}

        <div className="mt-5">
          <p className="mb-1.5 text-[14px] font-bold text-ink">
            Did you submit an income tax return (e-TIN) last year?{" "}
            <span className="font-normal text-muted">(optional)</span>
          </p>
          <div className="flex gap-2">
            {(
              [
                ["yes", "Yes"],
                ["no", "No"],
                ["unsure", "Not sure"],
              ] as const
            ).map(([val, label]) => (
              <button
                key={val}
                type="button"
                onClick={() => setTax(val)}
                className={cn(
                  "flex min-h-11 flex-1 items-center justify-center rounded-lg border-2 px-2 text-[13px] font-semibold",
                  tax === val
                    ? "border-brand bg-brand-soft text-brand-deep"
                    : "border-line bg-bg text-ink",
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {occ === "self" ? (
          <div className="mt-5">
            <p className="mb-1 text-[14px] font-bold text-ink">
              Do you meet our usual minimum for a business owner?{" "}
              <span className="font-normal text-muted">(optional)</span>
            </p>
            <p className="mb-2 text-[13px] leading-snug text-muted">
              Generally: average monthly income of BDT 40,000 or more, and a trade licence at least 2
              years old. Higher-value cards ask for more — your officer can confirm the exact figures.
            </p>
            <div className="flex gap-2">
              {(
                [
                  ["yes", "Yes, I meet this"],
                  ["no", "Not yet"],
                ] as const
              ).map(([val, label]) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setBiz(val)}
                  className={cn(
                    "flex min-h-11 flex-1 items-center justify-center rounded-lg border-2 px-3 text-center text-[13px] font-semibold",
                    biz === val
                      ? "border-brand bg-brand-soft text-brand-deep"
                      : "border-line bg-bg text-ink",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        ) : null}

        {occ === "defence" ? (
          <div className="mt-5">
            <label htmlFor="rank" className="mb-1.5 block text-[14px] font-bold text-ink">
              Your rank <span className="font-normal text-muted">(optional)</span>
            </label>
            <select
              id="rank"
              value={rank}
              onChange={(e) => setRank(e.target.value)}
              className="min-h-12 w-full rounded-lg border border-line bg-bg px-3 text-[15px] text-ink outline-none focus-visible:ring-2 focus-visible:ring-gold"
            >
              <option value="">Choose your rank</option>
              {RANKS.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.label}
                </option>
              ))}
            </select>
            <p className="mt-1.5 text-[13px] text-muted">
              Or the equivalent rank in the Navy or Air Force. Limits are set by rank; no income
              calculation is needed.
            </p>
          </div>
        ) : null}
      </section>

      {occ ? (
        <button
          type="button"
          onClick={() => setTab("cards")}
          className="min-h-12 rounded-xl bg-brand px-5 text-[16px] font-bold text-white shadow-border active:scale-[0.99]"
        >
          See your cards
        </button>
      ) : null}
    </div>
  );
}
