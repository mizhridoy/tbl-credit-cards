import { useEffect } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/cn";
import { CARDS, type CardId } from "@/lib/tbl-data";
import {
  bestOf,
  cardOrder,
  evalCard,
  isStarted,
  minText,
  reasonText,
  unknownText,
} from "@/lib/eligibility";
import { useQuiz } from "@/lib/store";
import { PlasticCard } from "@/components/plastic-card";

function Rung({ id, best }: { id: CardId; best: CardId | "" }) {
  const occ = useQuiz((s) => s.occ);
  const income = useQuiz((s) => s.income);
  const tenure = useQuiz((s) => s.tenure);
  const tax = useQuiz((s) => s.tax);
  const biz = useQuiz((s) => s.biz);
  const rank = useQuiz((s) => s.rank);
  const selected = useQuiz((s) => s.selected);
  const open = useQuiz((s) => s.open[id] ?? false);
  const toggleOpen = useQuiz((s) => s.toggleOpen);
  const setSelected = useQuiz((s) => s.setSelected);
  const slice = { occ, income, tenure, tax, biz, rank };
  const c = CARDS[id];
  const r = id === "plus" ? null : evalCard(id, slice);
  const isBest = r?.status === "ok" && id === best;

  let status: "ok" | "partial" | "no" | "info" | "" = "";
  if (id === "plus") status = "info";
  else if (r) status = r.status;

  return (
    <article
      className={cn(
        "overflow-hidden rounded-2xl border bg-surface shadow-border",
        status === "ok" && "border-l-4 border-l-brand",
        isBest && "border-brand ring-1 ring-brand",
        status === "partial" && "border-l-4 border-l-gold",
        status === "no" && "border-l-4 border-l-warn",
        status === "info" && "border-l-4 border-l-muted bg-surface-warm",
        status === "" && "border-line",
      )}
    >
      <button
        type="button"
        className="flex w-full items-center gap-3 px-3.5 py-3 text-left"
        onClick={() => toggleOpen(id, !open)}
        aria-expanded={open}
      >
        <div className="w-28 shrink-0">
          <PlasticCard name={c.short} limit={c.limit} tone={c.tone} compact />
        </div>
        <span className="min-w-0 flex-1">
          {isBest ? (
            <span className="mb-0.5 block text-[11px] font-bold text-brand">Best match</span>
          ) : null}
          <span className="block font-display text-[16px] font-semibold leading-tight text-ink">
            {c.name}
          </span>
          <span className="mt-0.5 block text-[12.5px] leading-snug text-muted">
            {c.limit} · {c.fee}
          </span>
        </span>
        <span className="flex shrink-0 flex-col items-end gap-2">
          {status === "ok" ? (
            <span className="rounded-full bg-brand px-2 py-0.5 text-[11px] font-bold text-white">
              You qualify
            </span>
          ) : null}
          {status === "partial" && id !== "plus" ? (
            <span className="rounded-full border border-gold-line bg-gold-soft px-2 py-0.5 text-[11px] font-bold text-gold">
              Tell us more
            </span>
          ) : null}
          {status === "no" ? (
            <span className="rounded-full border border-warn bg-warn-soft px-2 py-0.5 text-[11px] font-bold text-warn">
              Not yet
            </span>
          ) : null}
          {status === "info" ? (
            <span className="rounded-full border border-line bg-bg px-2 py-0.5 text-[11px] font-bold text-muted">
              Ask our team
            </span>
          ) : null}
          <ChevronDown
            className={cn("size-5 text-gold transition-transform duration-fast", open && "rotate-180")}
          />
        </span>
      </button>

      {open ? (
        <div className="border-t border-line px-3.5 pb-4 pt-3">
          {id === "plus" ? (
            <p className="rounded-lg bg-bg-soft px-3 py-2 text-[13.5px] text-ink">
              Eligibility for this card is confirmed by the bank when you apply.
            </p>
          ) : occ === "defence" && r?.status === "ok" ? (
            <p className="rounded-lg bg-bg-soft px-3 py-2 text-[13.5px] text-ink">
              {r.limitNote ? `Limit for your rank: ${r.limitNote}. ` : ""}
              Final limit is confirmed by the bank.
            </p>
          ) : (
            <p className="rounded-lg bg-bg-soft px-3 py-2 text-[13.5px] text-ink">{minText(id, slice)}</p>
          )}

          {r?.status === "no" && r.blockers.length ? (
            <ul className="mt-2 list-disc rounded-lg bg-warn-soft px-7 py-2 text-[13.5px] text-ink">
              {r.blockers.map((b) => (
                <li key={b.type}>{reasonText(b, slice)}</li>
              ))}
            </ul>
          ) : null}

          {r?.status === "partial" && r.unknown.length ? (
            <ul className="mt-2 list-disc rounded-lg bg-warn-soft px-7 py-2 text-[13.5px] text-ink">
              {r.unknown.map((u) => (
                <li key={u}>{unknownText(u)}</li>
              ))}
            </ul>
          ) : null}

          {r?.status === "ok" && r.caveats.length
            ? r.caveats.map((cv) => (
                <p key={cv} className="mt-2 rounded-lg bg-gold-soft px-3 py-2 text-[13.5px] text-caveat">
                  {cv}
                </p>
              ))
            : null}

          <h3 className="mt-3 text-[14px] font-bold text-brand">What you get</h3>
          <ul className="mt-1.5 list-disc space-y-1 pl-5 text-[14px] text-ink">
            {c.feats.map((f) => (
              <li key={f}>{f}</li>
            ))}
          </ul>
          <p className="mt-2 text-[13px] text-muted">
            Credit limit: {c.limit}. Annual fee: {c.fee}, before 15% VAT.
          </p>
          {r?.status === "ok" ? (
            <button
              type="button"
              onClick={() => setSelected(id)}
              className="mt-3 min-h-10 rounded-lg bg-brand px-4 text-[14px] font-bold text-white"
            >
              {selected === id ? "Selected — see documents" : "Choose this card"}
            </button>
          ) : null}
        </div>
      ) : null}
    </article>
  );
}

export function CardLadder() {
  const occ = useQuiz((s) => s.occ);
  const income = useQuiz((s) => s.income);
  const tenure = useQuiz((s) => s.tenure);
  const tax = useQuiz((s) => s.tax);
  const biz = useQuiz((s) => s.biz);
  const rank = useQuiz((s) => s.rank);
  const autoOpened = useQuiz((s) => s.autoOpened);
  const selected = useQuiz((s) => s.selected);
  const markAutoOpened = useQuiz((s) => s.markAutoOpened);
  const slice = { occ, income, tenure, tax, biz, rank };
  const best = bestOf(slice);
  const started = isStarted(slice);

  useEffect(() => {
    if (!autoOpened && best) markAutoOpened(best);
  }, [autoOpened, best, markAutoOpened]);

  useEffect(() => {
    if (!selected) return;
    const rr = evalCard(selected, { occ, income, tenure, tax, biz, rank });
    if (rr.status !== "ok") useQuiz.setState({ selected: "" });
  }, [selected, occ, income, tenure, tax, biz, rank]);

  const order = started ? [...cardOrder(occ), "plus" as const] : CIVIL_WITH_PLUS;

  return (
    <div className="flex flex-col gap-4 pb-8">
      <header>
        <p className="text-xs font-semibold tracking-[0.16em] text-brand uppercase">Step 2</p>
        <h1 className="mt-1 font-display text-[24px] font-semibold leading-tight text-brand-deep text-balance">
          Our cards, and where you stand
        </h1>
        {!started ? (
          <p className="mt-2 text-[14px] text-muted">
            Tap any card to see its features and minimum requirements. Answer question 1 to see where
            you stand on each.
          </p>
        ) : best ? (
          <p className="mt-2 text-[14px] text-lede">
            Best match: <span className="font-bold text-brand">{CARDS[best].name}</span>. Tap a card
            for features.
          </p>
        ) : (
          <p className="mt-2 text-[14px] text-lede">
            Fill in a bit more on the You tab, or tap a card to see what it asks for.
          </p>
        )}
      </header>
      <div className="flex flex-col gap-2.5">
        {order.map((id) => (
          <Rung key={id} id={id} best={best} />
        ))}
      </div>
    </div>
  );
}

const CIVIL_WITH_PLUS: CardId[] = ["signature", "platinum", "gold", "classic", "plus"];
