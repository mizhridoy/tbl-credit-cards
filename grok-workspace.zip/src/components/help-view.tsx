import { FAQS, GLANCE_ROWS } from "@/lib/tbl-data";

export function HelpView() {
  return (
    <div className="flex flex-col gap-6 pb-8">
      <header>
        <p className="text-xs font-semibold tracking-[0.16em] text-brand uppercase">Reference</p>
        <h1 className="mt-1 font-display text-[24px] font-semibold leading-tight text-brand-deep">
          Minimum requirements at a glance
        </h1>
      </header>

      <div className="overflow-x-auto rounded-2xl bg-surface shadow-border">
        <table className="glance-table w-full border-collapse text-left text-[13px] leading-snug">
          <thead>
            <tr className="bg-bg-soft text-[12.5px] font-bold text-brand-deep">
              <th className="px-2.5 py-2">Card</th>
              <th className="px-2.5 py-2">Credit limit</th>
              <th className="px-2.5 py-2">Annual fee</th>
              <th className="px-2.5 py-2">Govt salary</th>
              <th className="px-2.5 py-2">Private salary</th>
              <th className="px-2.5 py-2">Business income</th>
            </tr>
          </thead>
          <tbody>
            {GLANCE_ROWS.map((row) => (
              <tr key={row.card} className="border-t border-line">
                <td className="px-2.5 py-2 font-bold text-ink">{row.card}</td>
                <td className="px-2.5 py-2">{row.limit}</td>
                <td className="px-2.5 py-2 tabular-nums">{row.fee}</td>
                {"note" in row && row.note ? (
                  <td className="px-2.5 py-2" colSpan={3}>
                    {row.note}
                  </td>
                ) : (
                  <>
                    <td className="px-2.5 py-2 tabular-nums">{"govt" in row ? row.govt : ""}</td>
                    <td className="px-2.5 py-2 tabular-nums">{"private" in row ? row.private : ""}</td>
                    <td className="px-2.5 py-2 tabular-nums">{"biz" in row ? row.biz : ""}</td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-[13px] leading-relaxed text-muted">
        Amounts are monthly, in BDT. Fees are before 15% VAT. Classic, Gold and SENA also need about
        a year of experience (or 2 years in business); Platinum and Signature need about 5 years.
        Meeting a minimum does not guarantee approval.
      </p>

      <section>
        <h2 className="font-display text-[22px] font-semibold text-brand-deep">Common questions</h2>
        <div className="mt-3 flex flex-col gap-2">
          {FAQS.map((f) => (
            <details key={f.q} className="group rounded-2xl bg-surface shadow-border">
              <summary className="flex cursor-pointer list-none items-center gap-2 px-4 py-3.5 text-[15px] font-bold text-ink [&::-webkit-details-marker]:hidden">
                <span className="flex-1">{f.q}</span>
                <span className="font-display text-xl text-gold group-open:hidden">+</span>
                <span className="hidden font-display text-xl text-gold group-open:inline">–</span>
              </summary>
              <div className="px-4 pb-3.5 text-[14.5px] leading-relaxed text-lede">
                <p>{f.a}</p>
              </div>
            </details>
          ))}
        </div>
      </section>

      <p className="border-t border-line pt-4 text-[12.5px] leading-relaxed text-muted">
        Figures are indicative and before 15% VAT. The bank's current schedule of charges and
        credit policy apply. Meeting a minimum does not guarantee approval. Never share your PIN,
        OTP or full card number with anyone.
      </p>
    </div>
  );
}
