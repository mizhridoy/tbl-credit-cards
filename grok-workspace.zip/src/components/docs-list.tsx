import { CARDS } from "@/lib/tbl-data";
import { bestOf, currentDocsCard, docsFor, isStarted } from "@/lib/eligibility";
import { useQuiz } from "@/lib/store";
import { cn } from "@/lib/cn";

export function DocsList() {
  const occ = useQuiz((s) => s.occ);
  const income = useQuiz((s) => s.income);
  const tenure = useQuiz((s) => s.tenure);
  const tax = useQuiz((s) => s.tax);
  const biz = useQuiz((s) => s.biz);
  const rank = useQuiz((s) => s.rank);
  const selected = useQuiz((s) => s.selected);
  const ticked = useQuiz((s) => s.ticked);
  const setTicked = useQuiz((s) => s.setTicked);
  const setTab = useQuiz((s) => s.setTab);
  const slice = { occ, income, tenure, tax, biz, rank };
  const best = bestOf(slice);
  const started = isStarted(slice);
  const id = currentDocsCard({ ...slice, selected }, best);
  const list = docsFor(slice, id);
  const total = list.filter((d) => !d.bank).length;
  const done = list.filter((d) => !d.bank && ticked[d.t]).length;
  const pct = total ? Math.round((done * 100) / total) : 0;

  const sub = !started
    ? ""
    : selected
      ? "Tick what you already have."
      : best
        ? "Showing your best match. Choose another card to change it."
        : "You’re not at the minimum yet — this list is for the easiest card, so you can start preparing.";

  return (
    <div className="flex flex-col gap-4 pb-8">
      <header>
        <p className="text-xs font-semibold tracking-[0.16em] text-brand uppercase">Step 3</p>
        <h1 className="mt-1 font-display text-[24px] font-semibold leading-tight text-brand-deep">
          Documents to prepare
        </h1>
      </header>

      <section className="rounded-2xl bg-surface p-4 shadow-border">
        {!started ? (
          <p className="text-[14px] text-muted">Answer question 1 to see your document list.</p>
        ) : (
          <>
            <h2 className="font-display text-[18px] font-semibold text-brand-deep">
              For {CARDS[id].name}
            </h2>
            <p className="mt-0.5 text-[13px] text-muted">{sub}</p>
            <div className="mt-3 h-2.5 overflow-hidden rounded-md border border-line bg-bg">
              <div
                className="h-full bg-brand transition-[width] duration-fast ease-smooth"
                style={{ width: `${pct}%` }}
              />
            </div>
            <p className="mt-1 text-[13px] tabular-nums text-ink">
              {done} of {total} ready
            </p>
            <ul className="mt-3 flex flex-col gap-1.5">
              {list.map((d) => {
                const on = !!ticked[d.t];
                return (
                  <li key={d.t}>
                    <label
                      className={cn(
                        "flex min-h-12 cursor-pointer items-start gap-2.5 rounded-xl border px-3 py-2.5",
                        on ? "border-brand bg-brand-soft" : "border-line bg-bg",
                      )}
                    >
                      <input
                        type="checkbox"
                        checked={on}
                        onChange={(e) => setTicked(d.t, e.target.checked)}
                        className="mt-0.5 size-5 accent-brand"
                      />
                      <span className="text-[14px] leading-snug text-ink">
                        {d.t}
                        {d.bank ? (
                          <span className="ml-1.5 inline-block rounded-full bg-brand-soft px-2 py-0.5 text-[11px] font-bold text-brand">
                            We arrange this
                          </span>
                        ) : null}
                      </span>
                    </label>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </section>

      <button
        type="button"
        onClick={() => setTab("send")}
        className="min-h-12 rounded-xl bg-brand px-5 text-[16px] font-bold text-white"
      >
        Send your details
      </button>
    </div>
  );
}
