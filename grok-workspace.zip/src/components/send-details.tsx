import { useMemo, useState, type ReactNode } from "react";
import { Copy, Mail, MessageCircle, Phone } from "lucide-react";
import { CALL_TIMES, CARDS, OCC_LABELS, OFFICER } from "@/lib/tbl-data";
import {
  BD_MOBILE,
  EMAIL_OK,
  bestOf,
  currentDocsCard,
  docsFor,
  findRank,
  fmt,
  isStarted,
  qualifiesNames,
} from "@/lib/eligibility";
import { useQuiz } from "@/lib/store";

function tenureLabel(v: string) {
  return v === "yes" ? "Yes" : v === "no" ? "Not yet" : "";
}
function taxLabel(v: string) {
  return v === "yes" ? "Yes" : v === "no" ? "No" : v === "unsure" ? "Not sure" : "";
}
function bizLabel(v: string) {
  return v === "yes" ? "Yes, meets it" : v === "no" ? "Not yet" : "";
}

export function SendDetails() {
  const occ = useQuiz((s) => s.occ);
  const income = useQuiz((s) => s.income);
  const tenure = useQuiz((s) => s.tenure);
  const tax = useQuiz((s) => s.tax);
  const biz = useQuiz((s) => s.biz);
  const rank = useQuiz((s) => s.rank);
  const selected = useQuiz((s) => s.selected);
  const ticked = useQuiz((s) => s.ticked);

  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [area, setArea] = useState("");
  const [time, setTime] = useState<(typeof CALL_TIMES)[number]>("Any time");
  const [consent, setConsent] = useState(false);
  const [errs, setErrs] = useState("");
  const [summary, setSummary] = useState("");
  const [mailHref, setMailHref] = useState("");
  const [waHref, setWaHref] = useState("");
  const [status, setStatus] = useState("");
  const [copied, setCopied] = useState(false);

  const slice = useMemo(
    () => ({ occ, income, tenure, tax, biz, rank }),
    [occ, income, tenure, tax, biz, rank],
  );
  const best = bestOf(slice);

  function buildSummary() {
    const L: string[] = [];
    L.push("Trust Bank credit card enquiry (self-declared, subject to bank verification)");
    L.push(`To: ${OFFICER.name} — ${OFFICER.title}`);
    try {
      L.push(
        `Sent: ${new Date().toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}`,
      );
    } catch {
      /* ignore */
    }
    L.push(`Name: ${name.trim()}`);
    L.push(`Mobile: ${mobile.trim()}`);
    if (email.trim()) L.push(`Email: ${email.trim()}`);
    if (area.trim()) L.push(`Nearest branch or area: ${area.trim()}`);
    L.push(`Best time to call: ${time}`);
    if (occ) {
      L.push(`Source of income: ${OCC_LABELS[occ]}`);
      if (occ === "defence") {
        const rk = findRank(rank);
        if (rk) L.push(`Rank: ${rk.label}`);
      } else {
        if (income) L.push(`Monthly income: BDT ${fmt(income)}`);
        if (tenure) L.push(`At least 3 months in role: ${tenureLabel(tenure)}`);
        if (occ === "self" && biz) L.push(`Meets minimum business requirement: ${bizLabel(biz)}`);
      }
      if (tax) L.push(`Tax return filed last year: ${taxLabel(tax)}`);
    }
    if (isStarted(slice)) {
      const qualifies = qualifiesNames(slice);
      const bestName = best ? CARDS[best].name : qualifies[0] ?? "";
      L.push(
        `ELIGIBILITY STATUS: ${
          qualifies.length
            ? `MEETS MINIMUM (best match: ${bestName})`
            : "NOT YET AT MINIMUM, OR NEEDS MORE INFO"
        }`,
      );
      if (qualifies.length) L.push(`Qualifies for: ${qualifies.join(", ")}`);
      const id = currentDocsCard({ ...slice, selected }, best);
      L.push(`Interested in: ${CARDS[id].name}`);
      const list = docsFor(slice, id).filter((d) => !d.bank);
      const ready = list.filter((d) => ticked[d.t]);
      const todo = list.filter((d) => !ticked[d.t]);
      L.push(`Documents ready: ${ready.length} of ${list.length}`);
      if (todo.length) L.push(`Still to arrange: ${todo.map((d) => d.t).join("; ")}`);
    }
    return L.join("\n");
  }

  function send() {
    const errors: string[] = [];
    if (name.trim().length < 2) errors.push("Enter your full name.");
    const m2 = mobile.replace(/[\s-]/g, "");
    if (!BD_MOBILE.test(m2)) errors.push("Enter a valid mobile number, for example 01712345678.");
    if (email.trim() && !EMAIL_OK.test(email.trim())) errors.push("Check your email address.");
    if (!consent) errors.push("Tick the box to agree to be contacted.");
    if (errors.length) {
      setErrs(errors.join(" "));
      setSummary("");
      return;
    }
    setErrs("");
    const text = buildSummary();
    setSummary(text);
    const enc = encodeURIComponent(text);
    const eligTag = best ? "Eligible" : isStarted(slice) ? "Needs review" : "Enquiry";
    const subject = `Credit card enquiry — ${name.trim() || "New applicant"} — ${eligTag}`;
    const wa = `https://wa.me/${OFFICER.whatsapp}?text=${enc}`;
    const mail = `mailto:${OFFICER.email}?subject=${encodeURIComponent(subject)}&body=${enc}`;
    setWaHref(wa);
    setMailHref(mail);
    let waWin: Window | null = null;
    try {
      waWin = window.open(wa, "_blank", "noopener");
    } catch {
      waWin = null;
    }
    try {
      window.open(mail, "_blank", "noopener");
    } catch {
      /* preview may block */
    }
    const bits: string[] = [];
    if (!waWin) bits.push('If WhatsApp did not open, tap "Open WhatsApp again" below.');
    bits.push('If your email app did not open, tap "Open email again" below.');
    setStatus(`Sending to ${OFFICER.name}. ${bits.join(" ")}`);
  }

  async function copySummary() {
    try {
      await navigator.clipboard.writeText(summary);
      setCopied(true);
      setStatus("Copied. Paste it into WhatsApp, SMS or email.");
    } catch {
      setStatus("Press and hold the text above to copy it.");
    }
  }

  return (
    <div className="flex flex-col gap-4 pb-8">
      <header>
        <p className="text-xs font-semibold tracking-[0.16em] text-brand uppercase">Step 4</p>
        <h1 className="mt-1 font-display text-[24px] font-semibold leading-tight text-brand-deep">
          Send your details
        </h1>
        <p className="mt-2 text-[14px] text-muted">
          Only your name and number are required. Everything else helps us serve you faster.
        </p>
      </header>

      <section className="rounded-2xl bg-surface p-4 shadow-border">
        <Field label="Full name" htmlFor="c-name">
          <input
            id="c-name"
            autoComplete="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="field-input"
          />
        </Field>
        <Field label="Mobile number" htmlFor="c-mobile">
          <input
            id="c-mobile"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder="01XXXXXXXXX"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            className="field-input"
          />
        </Field>
        <Field label="Email" htmlFor="c-email" optional>
          <input
            id="c-email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="field-input"
          />
        </Field>
        <Field label="Nearest branch or area" htmlFor="c-area" optional>
          <input
            id="c-area"
            autoComplete="off"
            placeholder="e.g. Uttara, Dhaka"
            value={area}
            onChange={(e) => setArea(e.target.value)}
            className="field-input"
          />
        </Field>
        <Field label="Best time to call" htmlFor="c-time" optional>
          <select
            id="c-time"
            value={time}
            onChange={(e) => setTime(e.target.value as (typeof CALL_TIMES)[number])}
            className="field-input"
          >
            {CALL_TIMES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>

        <p className="mt-4 rounded-xl bg-brand-soft px-3 py-2.5 text-[13.5px] leading-snug text-ink">
          Your details go to <b>{OFFICER.name}</b>, {OFFICER.title}.
        </p>

        <label className="mt-4 flex items-start gap-2.5 text-[13.5px] leading-snug text-ink">
          <input
            type="checkbox"
            checked={consent}
            onChange={(e) => setConsent(e.target.checked)}
            className="mt-0.5 size-5 shrink-0 accent-brand"
          />
          <span>
            I agree that Trust Bank may contact me about a credit card, and that sending this will
            open my email and WhatsApp app addressed to the officer above. My details are
            self-declared and will be verified by the bank.
          </span>
        </label>

        {errs ? (
          <p className="mt-3 text-[14px] font-semibold text-warn" role="alert">
            {errs}
          </p>
        ) : null}

        <button
          type="button"
          onClick={send}
          className="mt-4 min-h-12 w-full rounded-xl bg-brand text-[16px] font-bold text-white"
        >
          Send my details
        </button>

        {summary ? (
          <div className="mt-4">
            <h2 className="text-[14px] font-bold text-brand">Your summary</h2>
            <textarea
              readOnly
              aria-label="Your summary"
              value={summary}
              className="mt-2 min-h-44 w-full resize-y rounded-lg border border-line bg-bg p-3 text-[13.5px] leading-snug text-ink"
            />
            <div className="mt-3 flex flex-wrap gap-2">
              {mailHref ? (
                <a
                  className="inline-flex min-h-10 items-center gap-1.5 rounded-lg bg-brand px-3 text-[14px] font-bold text-white"
                  href={mailHref}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Mail className="size-4" /> Open email again
                </a>
              ) : null}
              {waHref ? (
                <a
                  className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-brand px-3 text-[14px] font-bold text-brand"
                  href={waHref}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <MessageCircle className="size-4" /> Open WhatsApp again
                </a>
              ) : null}
              <button
                type="button"
                onClick={copySummary}
                className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-brand px-3 text-[14px] font-bold text-brand"
              >
                <Copy className="size-4" /> {copied ? "Copied" : "Copy summary"}
              </button>
            </div>
            {status ? (
              <p className="mt-2 text-[13.5px] font-semibold text-brand" role="status">
                {status}
              </p>
            ) : null}
          </div>
        ) : null}

        <div className="mt-5 flex flex-wrap gap-2">
          <a
            className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-brand px-3 text-[14px] font-bold text-brand"
            href="tel:16201"
          >
            <Phone className="size-4" /> Call 16201
          </a>
          <a
            className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-brand px-3 text-[14px] font-bold text-brand"
            href="https://www.tblbd.com"
            target="_blank"
            rel="noopener noreferrer"
          >
            Visit tblbd.com
          </a>
        </div>
      </section>
    </div>
  );
}

function Field({
  label,
  htmlFor,
  optional,
  children,
}: {
  label: string;
  htmlFor: string;
  optional?: boolean;
  children: ReactNode;
}) {
  return (
    <div className="mt-3 first:mt-0">
      <label htmlFor={htmlFor} className="mb-1.5 block text-[14px] font-bold text-ink">
        {label} {optional ? <span className="font-normal text-muted">(optional)</span> : null}
      </label>
      {children}
    </div>
  );
}
