import { cn } from "@/lib/cn";
import type { CardTone } from "@/lib/tbl-data";

const TONES: Record<CardTone, string> = {
  classic: "from-brand to-brand-deep text-white",
  gold: "from-gold to-gold-deep text-white",
  platinum: "from-platinum to-brand-deep text-white",
  signature: "from-brand-deep to-ink text-gold-soft",
  plus: "from-ink to-brand-deep text-gold-soft",
  sena: "from-sena to-brand-deep text-white",
};

export function PlasticCard({
  name,
  limit,
  tone,
  compact,
}: {
  name: string;
  limit: string;
  tone: CardTone;
  compact?: boolean;
}) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl bg-linear-to-br shadow-card",
        TONES[tone],
        compact ? "aspect-card px-3.5 py-3" : "aspect-card px-4 py-3.5",
      )}
    >
      <div className="pointer-events-none absolute -right-6 -top-8 size-28 rounded-full bg-white/10" />
      <div className="pointer-events-none absolute -bottom-10 -left-8 size-32 rounded-full bg-black/10" />
      <div className="relative flex h-full flex-col justify-between">
        <div className="flex items-start justify-between gap-2">
          <img
            src="/tbl-mark.svg"
            alt=""
            className="h-8 w-8 object-contain drop-shadow-sm"
          />
          <span className="text-[10px] font-semibold tracking-[0.18em] uppercase opacity-80">
            Trust Bank
          </span>
        </div>
        <div className="flex items-end justify-between gap-2">
          <div className="min-w-0">
            <p className="truncate font-display text-[15px] font-semibold leading-tight">{name}</p>
            <p className="mt-0.5 text-[11px] font-medium opacity-80">{limit}</p>
          </div>
          <span className="shrink-0 text-[11px] font-bold tracking-widest opacity-90">VISA</span>
        </div>
      </div>
    </div>
  );
}
