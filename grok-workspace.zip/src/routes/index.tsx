import { createFileRoute } from "@tanstack/react-router";
import { AndroidShell } from "@/components/android-shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AndroidShell />;
}
