export type Occupancy = "" | "govt" | "private" | "self" | "defence";
export type YesNo = "" | "yes" | "no";
export type TaxAnswer = "" | "yes" | "no" | "unsure";
export type CardId = "classic" | "gold" | "platinum" | "signature" | "plus" | "sena";
export type CivilCardId = "classic" | "gold" | "platinum" | "signature";

export const OFFICER = {
  name: "Md. Mizanor Rahman Hridoy",
  title: "Assistant Officer & Bangla QR Branding Officer, Uttara Corporate Branch, Trust Bank PLC",
  email: "mizanor.rahman@tblbd.com",
  whatsapp: "8801538043323",
} as const;

export const INCOME_CHIPS = [18000, 30000, 50000, 100000, 200000, 400000] as const;

export const RULES: Record<
  CivilCardId,
  { inc: { govt: number; private: number; self: number }; ten: string }
> = {
  classic: {
    inc: { govt: 15000, private: 30000, self: 40000 },
    ten: "About 1 year of experience (6 months with your current employer), or 2 years in business.",
  },
  gold: {
    inc: { govt: 15000, private: 30000, self: 40000 },
    ten: "About 1 year of experience (6 months with your current employer), or 2 years in business.",
  },
  platinum: {
    inc: { govt: 50000, private: 100000, self: 150000 },
    ten: "About 5 years of experience, or 3 years in business.",
  },
  signature: {
    inc: { govt: 100000, private: 150000, self: 200000 },
    ten: "About 5 years of experience, or 5 years in business.",
  },
};

export type CardTone = "classic" | "gold" | "platinum" | "signature" | "plus" | "sena";

export const CARDS: Record<
  CardId,
  { name: string; limit: string; fee: string; feats: string[]; tone: CardTone; short: string }
> = {
  classic: {
    name: "Visa Classic",
    short: "Classic",
    limit: "Up to BDT 1.2 lac",
    fee: "BDT 1,000 a year",
    tone: "classic",
    feats: [
      "Up to 45 days interest-free on purchases when you pay the full statement amount",
      "Annual fee waived from year 2 after 18 POS or e-commerce transactions (BDT 500 or more each)",
      "Up to 4 supplementary cards, the first one free",
      "EMV chip-secured card, with 0% EMI and discounts at listed merchants",
      "Transaction alerts by email and SMS",
      "50% off the card fee for serving defence personnel",
    ],
  },
  gold: {
    name: "Visa Gold",
    short: "Gold",
    limit: "BDT 1.2 lac to 5 lac",
    fee: "BDT 2,000 a year",
    tone: "gold",
    feats: [
      "Everything in Classic",
      "Airport Meet and Greet for the cardholder",
      "No cash withdrawal fee at Trust Bank ATMs (interest still applies on cash withdrawals)",
      "Pay bills through internet banking and mobile apps",
    ],
  },
  platinum: {
    name: "Visa Platinum",
    short: "Platinum",
    limit: "BDT 2 lac to 5 lac",
    fee: "BDT 3,000 a year",
    tone: "platinum",
    feats: [
      "2 free international airport lounge visits a year, plus 1 Balaka Lounge visit",
      "Airport Meet and Greet with 2 companions",
      "Offers at partner merchants such as Aarong",
      "0% EMI and discounts at listed merchants",
    ],
  },
  signature: {
    name: "Visa Signature",
    short: "Signature",
    limit: "BDT 4 lac to 10 lac",
    fee: "BDT 5,000 a year",
    tone: "signature",
    feats: [
      "4 free international airport lounge visits a year, plus 2 Balaka Lounge visits",
      "Airport Meet and Greet with 3 companions",
      "Buy-one-get-one dining at Radisson Dhaka, Radisson Chittagong, InterContinental Dhaka and other partners",
      "Offers at partner merchants such as Aarong",
    ],
  },
  plus: {
    name: "Visa Signature Plus",
    short: "Signature Plus",
    limit: "BDT 5 lac to 10 lac",
    fee: "BDT 12,000 a year",
    tone: "plus",
    feats: [
      "Up to 12 free international airport lounge visits a year",
      "8 complimentary airport pick-and-drop services",
      "Annual health check-up on BDT 4 lac yearly POS and e-commerce spend",
      "Buy-one-get-1/2/3 free buffet offers at leading hotels",
    ],
  },
  sena: {
    name: "TBL SENA Card",
    short: "SENA",
    limit: "Set by your rank",
    fee: "No issuance fee",
    tone: "sena",
    feats: [
      "For serving JCOs and NCOs of the armed forces",
      "Renewal fee waived after 18 POS or e-commerce transactions",
      "Pre-approved limit based on your rank, with no debt-burden calculation",
      "A higher limit, up to twice your salary, may be possible with a satisfactory debt-burden ratio",
      "Only 3 documents: NID, e-TIN with return slip, and office ID card",
    ],
  },
};

export type Rank = {
  id: string;
  label: string;
  cards: Partial<Record<CardId, string>>;
};

export const RANKS: Rank[] = [
  { id: "sainik", label: "Sainik", cards: { sena: "" } },
  { id: "lcpl", label: "Lance Corporal", cards: { sena: "" } },
  { id: "cpl", label: "Corporal", cards: { sena: "" } },
  { id: "sgt", label: "Sergeant", cards: { sena: "" } },
  { id: "wo", label: "Warrant Officer (JCO)", cards: { sena: "" } },
  { id: "swo", label: "Senior Warrant Officer", cards: { sena: "" } },
  { id: "mwo", label: "Master Warrant Officer / Honorary Captain", cards: { sena: "" } },
  { id: "lt", label: "Lieutenant", cards: { gold: "BDT 2 lac" } },
  { id: "capt", label: "Captain", cards: { gold: "BDT 3 lac" } },
  { id: "major", label: "Major", cards: { platinum: "BDT 4 lac" } },
  { id: "ltcol", label: "Lieutenant Colonel", cards: { platinum: "BDT 4 lac" } },
  { id: "col", label: "Colonel", cards: { platinum: "BDT 4 lac", signature: "up to BDT 8 lac" } },
  {
    id: "brig",
    label: "Brigadier General or above",
    cards: { platinum: "up to BDT 5 lac", signature: "up to BDT 10 lac" },
  },
];

export const CIVIL_ORDER: CardId[] = ["signature", "platinum", "gold", "classic"];
export const DEFENCE_ORDER: CardId[] = ["signature", "platinum", "gold", "sena"];

export const GLANCE_ROWS: {
  card: string;
  limit: string;
  fee: string;
  govt?: string;
  private?: string;
  biz?: string;
  note?: string;
}[] = [
  {
    card: "Classic",
    limit: "Up to BDT 1.2 lac",
    fee: "BDT 1,000",
    govt: "15,000",
    private: "30,000",
    biz: "40,000",
  },
  {
    card: "Gold",
    limit: "BDT 1.2 to 5 lac",
    fee: "BDT 2,000",
    govt: "15,000",
    private: "30,000",
    biz: "40,000",
  },
  {
    card: "Platinum",
    limit: "BDT 2 to 5 lac",
    fee: "BDT 3,000",
    govt: "50,000",
    private: "1,00,000",
    biz: "1,50,000",
  },
  {
    card: "Signature",
    limit: "BDT 4 to 10 lac",
    fee: "BDT 5,000",
    govt: "1,00,000",
    private: "1,50,000",
    biz: "2,00,000",
  },
  {
    card: "SENA",
    limit: "Set by rank",
    fee: "No issuance fee",
    note: "For serving JCOs and NCOs of the armed forces",
  },
];

export const FAQS = [
  {
    q: "Will meeting the minimum get me the card?",
    a: "Not automatically. This page gives you a quick, informal read. Your officer still confirms your income, experience and CIB report before approving a card and setting your final limit.",
  },
  {
    q: "What is a CIB report, and why does tax filing matter?",
    a: "CIB is Bangladesh Bank's record of your loans and card dues; a clear report is required. A valid e-TIN and last year's tax return are also required for a credit card, so it's worth sorting out before you apply if you haven't already.",
  },
  {
    q: "How long is the interest-free period?",
    a: "Up to 45 days on purchases, when you pay the full statement amount by the due date. Cash withdrawals do not get an interest-free period.",
  },
  {
    q: "How can I avoid the annual fee?",
    a: "On Classic, Gold, Platinum and Signature, it's waived from the second year after 18 POS or e-commerce transactions. The SENA card waives its renewal fee the same way.",
  },
  {
    q: "Can my family have cards too?",
    a: "Yes. You can add up to 4 supplementary cards, and the first one is free.",
  },
  {
    q: "I'm not there yet. What can I do?",
    a: "Check the note on each card above. You can also ask about a card secured against a fixed deposit (FDR), or apply again once your income or experience reaches the minimum.",
  },
  {
    q: "What happens to what I type here?",
    a: "Nothing is stored by this page. If you fill in your details and press “Send my details,” your own email and WhatsApp app open with a message already addressed to the officer named above — you review and send it yourself.",
  },
] as const;

export const OCC_OPTIONS: { value: Exclude<Occupancy, "">; title: string; sub: string }[] = [
  { value: "govt", title: "Government job", sub: "Or semi-government" },
  { value: "private", title: "Private job", sub: "Company, bank, NBFI, MNC" },
  { value: "self", title: "Own business", sub: "Or landlord" },
  { value: "defence", title: "Armed forces", sub: "Serving personnel" },
];

export const CALL_TIMES = [
  "Any time",
  "Morning (9 am to 12 pm)",
  "Afternoon (12 pm to 4 pm)",
  "Evening (4 pm to 7 pm)",
] as const;

export const OCC_LABELS: Record<Exclude<Occupancy, "">, string> = {
  govt: "Government / semi-government job",
  private: "Private job",
  self: "Own business or landlord",
  defence: "Armed forces",
};
