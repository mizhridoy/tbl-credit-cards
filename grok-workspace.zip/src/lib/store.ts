import { create } from "zustand";
import type { CardId, Occupancy, TaxAnswer, YesNo } from "@/lib/tbl-data";

export type TabId = "you" | "cards" | "docs" | "send";

type State = {
  occ: Occupancy;
  income: number;
  tenure: YesNo;
  tax: TaxAnswer;
  biz: YesNo;
  rank: string;
  selected: CardId | "";
  open: Record<string, boolean>;
  autoOpened: boolean;
  ticked: Record<string, boolean>;
  tab: TabId;
  helpOpen: boolean;
  setOcc: (occ: Occupancy) => void;
  setIncome: (n: number) => void;
  setTenure: (v: YesNo) => void;
  setTax: (v: TaxAnswer) => void;
  setBiz: (v: YesNo) => void;
  setRank: (v: string) => void;
  setSelected: (id: CardId) => void;
  toggleOpen: (id: string, open: boolean) => void;
  markAutoOpened: (id: CardId) => void;
  setTicked: (label: string, on: boolean) => void;
  setTab: (tab: TabId) => void;
  setHelpOpen: (open: boolean) => void;
};

export const useQuiz = create<State>((set) => ({
  occ: "",
  income: 0,
  tenure: "",
  tax: "",
  biz: "",
  rank: "",
  selected: "",
  open: {},
  autoOpened: false,
  ticked: {},
  tab: "you",
  helpOpen: false,
  setOcc: (occ) => set({ occ, autoOpened: false, selected: "", open: {} }),
  setIncome: (income) => set({ income }),
  setTenure: (tenure) => set({ tenure }),
  setTax: (tax) => set({ tax }),
  setBiz: (biz) => set({ biz }),
  setRank: (rank) => set({ rank, autoOpened: false }),
  setSelected: (selected) => set({ selected, tab: "docs" }),
  toggleOpen: (id, open) => set((s) => ({ open: { ...s.open, [id]: open } })),
  markAutoOpened: (id) => set((s) => ({ autoOpened: true, open: { ...s.open, [id]: true } })),
  setTicked: (label, on) => set((s) => ({ ticked: { ...s.ticked, [label]: on } })),
  setTab: (tab) => set({ tab, helpOpen: false }),
  setHelpOpen: (helpOpen) => set({ helpOpen }),
}));
