import {
  CARDS,
  CIVIL_ORDER,
  DEFENCE_ORDER,
  RANKS,
  RULES,
  type CardId,
  type CivilCardId,
  type Occupancy,
  type TaxAnswer,
  type YesNo,
} from "@/lib/tbl-data";

export type QuizSlice = {
  occ: Occupancy;
  income: number;
  tenure: YesNo;
  tax: TaxAnswer;
  biz: YesNo;
  rank: string;
};

export type Blocker = { type: "income"; need: number } | { type: "tenure" } | { type: "biz" } | { type: "rank" };

export type EvalResult = {
  status: "ok" | "partial" | "no";
  blockers: Blocker[];
  unknown: string[];
  caveats: string[];
  thresh?: number;
  limitNote?: string;
};

const NF = new Intl.NumberFormat("en-IN");
export function fmt(n: number) {
  return NF.format(n);
}

export function findRank(id: string) {
  return RANKS.find((r) => r.id === id) ?? null;
}

function groupOf(occ: Occupancy) {
  return occ === "govt" ? "govt" : occ === "private" ? "private" : "self";
}

export function isCivil(occ: Occupancy) {
  return occ === "govt" || occ === "private" || occ === "self";
}

export function isStarted(s: QuizSlice) {
  return !!s.occ;
}

export function cardOrder(occ: Occupancy): CardId[] {
  return occ === "defence" ? DEFENCE_ORDER : CIVIL_ORDER;
}

function evalCivil(cardId: CivilCardId, s: QuizSlice): EvalResult {
  const g = groupOf(s.occ);
  const thresh = RULES[cardId].inc[g];
  const blockers: Blocker[] = [];
  const unknown: string[] = [];
  const caveats: string[] = [];
  if (s.occ === "self") {
    if (s.biz === "no") blockers.push({ type: "biz" });
    else if (s.biz === "") unknown.push("biz");
  }
  if (s.income > 0) {
    if (s.income < thresh) blockers.push({ type: "income", need: thresh });
  } else {
    unknown.push("income");
  }
  if (s.tenure === "no") blockers.push({ type: "tenure" });
  else if (s.tenure === "") unknown.push("tenure");
  if (cardId === "platinum" || cardId === "signature") {
    caveats.push(`Your officer will confirm you meet the full experience requirement: ${RULES[cardId].ten}`);
  }
  if (s.tax === "no") {
    caveats.push("You will need a valid e-TIN and last year’s tax return on file before applying.");
  } else if (s.tax === "unsure") {
    caveats.push("A valid e-TIN and tax return on file are required — check this before applying.");
  }
  const status = blockers.length ? "no" : unknown.length ? "partial" : "ok";
  return { status, blockers, unknown, caveats, thresh };
}

function evalDefence(cardId: CardId, s: QuizSlice): EvalResult {
  if (!s.rank) return { status: "partial", blockers: [], unknown: ["rank"], caveats: [] };
  const rk = findRank(s.rank);
  const has = !!rk && Object.prototype.hasOwnProperty.call(rk.cards, cardId);
  return {
    status: has ? "ok" : "no",
    blockers: has ? [] : [{ type: "rank" }],
    unknown: [],
    caveats: [],
    limitNote: has ? rk!.cards[cardId] : "",
  };
}

export function evalCard(cardId: CardId, s: QuizSlice): EvalResult {
  if (cardId === "plus") {
    return { status: "partial", blockers: [], unknown: [], caveats: [] };
  }
  return s.occ === "defence" ? evalDefence(cardId, s) : evalCivil(cardId as CivilCardId, s);
}

export function bestOf(s: QuizSlice): CardId | "" {
  if (!s.occ) return "";
  for (const id of cardOrder(s.occ)) {
    if (evalCard(id, s).status === "ok") return id;
  }
  return "";
}

export function reasonText(b: Blocker, s: QuizSlice) {
  if (b.type === "income") return `Needs BDT ${fmt(b.need)} or more a month. You entered BDT ${fmt(s.income)}.`;
  if (b.type === "tenure") return "Needs at least 3 months in your current role or business.";
  if (b.type === "biz") return "Doesn’t yet meet our minimum business-owner requirement (see question 1).";
  if (b.type === "rank") return "This card is not offered for your rank.";
  return "";
}

export function unknownText(u: string) {
  if (u === "income") return "Tell us your monthly income to check this.";
  if (u === "tenure") return "Tell us if you’ve been in your role at least 3 months.";
  if (u === "biz") return "Tell us if you meet our minimum business requirement.";
  if (u === "rank") return "Choose your rank to check this.";
  return "";
}

export function minText(cardId: CardId, s: QuizSlice) {
  if (s.occ === "defence") return "Rank-based limit. Final limit is confirmed by the bank.";
  if (cardId === "plus" || cardId === "sena") return CARDS[cardId].limit;
  const r = RULES[cardId as CivilCardId];
  return `Minimum monthly income: government job BDT ${fmt(r.inc.govt)}, private job BDT ${fmt(r.inc.private)}, business BDT ${fmt(r.inc.self)}. ${r.ten}`;
}

export type DocItem = { t: string; bank?: boolean };

export function docsFor(s: QuizSlice, cardId: CardId): DocItem[] {
  if (s.occ === "defence") {
    if (cardId === "sena") {
      return [
        { t: "NID photocopy" },
        { t: "e-TIN certificate with tax acknowledgement return slip" },
        { t: "Office ID card photocopy" },
      ];
    }
    return [
      { t: "Duly filled application form" },
      { t: "One passport-size photograph" },
      { t: "e-TIN certificate" },
      { t: "NID copy" },
      { t: "Office ID card photocopy" },
      { t: "Passport copy, if you want a dual-currency card" },
      { t: "Signed CIB undertaking form" },
    ];
  }
  const D: DocItem[] = [
    { t: "Duly filled application form" },
    { t: "One passport-size photograph" },
    { t: "NID copy" },
    { t: "e-TIN certificate with your latest tax return" },
    { t: "Recent utility bill copy, for address verification" },
    { t: "Signed CIB undertaking form" },
  ];
  if (s.occ === "self") {
    D.push({ t: "Trade licence, or partnership/company registration documents, whichever fits your business" });
    D.push({ t: "Last 12 months business bank statement" });
    D.push({ t: "Contact point verification and income visit report", bank: true });
  } else {
    D.push({ t: "Office ID card photocopy" });
    D.push({ t: "Salary certificate, letter of introduction (LOI) or pay slip" });
    D.push({ t: "Bank statement for the last 6 months" });
  }
  return D;
}

export function currentDocsCard(s: QuizSlice & { selected: CardId | "" }, best: CardId | "") {
  return s.selected || best || (s.occ === "defence" ? "sena" : "classic");
}

export function qualifiesNames(s: QuizSlice) {
  if (!s.occ) return [];
  return cardOrder(s.occ)
    .filter((id) => evalCard(id, s).status === "ok")
    .map((id) => CARDS[id].name);
}

export const BD_MOBILE = /^(\+?88)?01[3-9][0-9]{8}$/;
export const EMAIL_OK = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
